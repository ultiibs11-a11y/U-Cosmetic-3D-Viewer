'use strict';
const $=id=>document.getElementById(id), rad=Math.PI/180;
const status=s=>{$('status').textContent=s};
const I=()=>[1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1];
function mul(a,b){const r=new Array(16).fill(0);for(let c=0;c<4;c++)for(let row=0;row<4;row++)for(let k=0;k<4;k++)r[c*4+row]+=a[k*4+row]*b[c*4+k];return r}
const move=(x,y,z)=>{let m=I();m[12]=x;m[13]=y;m[14]=z;return m};
const scale=(x,y,z)=>{let m=I();m[0]=x;m[5]=y;m[10]=z;return m};
const rx=a=>{let m=I(),c=Math.cos(a),s=Math.sin(a);m[5]=c;m[6]=s;m[9]=-s;m[10]=c;return m};
const ry=a=>{let m=I(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[2]=-s;m[8]=s;m[10]=c;return m};
const rz=a=>{let m=I(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[1]=s;m[4]=-s;m[5]=c;return m};
const chain=(...mats)=>mats.reduce(mul,I());
const gl=$('scene').getContext('webgl',{alpha:false,antialias:true,preserveDrawingBuffer:true});
if(!gl)status('WebGL ist in diesem Browser nicht verfügbar.');
const VS='attribute vec3 pos;attribute vec2 tex;uniform mat4 mvp;varying vec2 uv;void main(){gl_Position=mvp*vec4(pos,1.);uv=tex;}';
const FS='precision mediump float;uniform sampler2D image;uniform vec4 tint;varying vec2 uv;void main(){vec4 c=texture2D(image,uv)*tint;if(c.a<0.05)discard;gl_FragColor=c;}';
function shader(type,src){let s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
let program;if(gl){program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,VS));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,FS));gl.linkProgram(program);gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);}
const posLoc=gl?.getAttribLocation(program,'pos'),uvLoc=gl?.getAttribLocation(program,'tex'),matrixLoc=gl?.getUniformLocation(program,'mvp'),tintLoc=gl?.getUniformLocation(program,'tint');
const vb=gl?.createBuffer(),tb=gl?.createBuffer();let white;
function texFromImage(img){let t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);return t}
if(gl){let c=document.createElement('canvas');c.width=c.height=1;c.getContext('2d').fillRect(0,0,1,1);white=texFromImage(c)}
function imageFromBlob(blob){return new Promise((ok,no)=>{let url=URL.createObjectURL(blob),im=new Image();im.onload=()=>{URL.revokeObjectURL(url);ok(im)};im.onerror=()=>{URL.revokeObjectURL(url);no(Error('PNG konnte nicht geöffnet werden'))};im.src=url})}
const faceIndices=[[4,5,6,4,6,7],[1,0,3,1,3,2],[0,4,7,0,7,3],[5,1,2,5,2,6],[3,7,6,3,6,2],[0,1,5,0,5,4]];
// 0 front (+Z), 1 back, 2 left, 3 right, 4 top, 5 bottom
function drawBox(m,ext,texture,rects,tint=[1,1,1,1]){
 let [x,y,z,w,h,d]=ext;if(w===0&&h===0&&d===0)return;
 const xx=x+w,yy=y+h,zz=z+d;
 let points=[[x,y,z],[xx,y,z],[xx,yy,z],[x,yy,z],[x,y,zz],[xx,y,zz],[xx,yy,zz],[x,yy,zz]];
 let verts=[],uvs=[];
 for(let face=0;face<6;face++){
  // Flat parts: render only perpendicular faces, unless three dimensions nonzero
  if((d===0&&face!==0&&face!==1)||(w===0&&face!==2&&face!==3)||(h===0&&face!==4&&face!==5))continue;
  let ids=faceIndices[face],r=rects[face]||rects[0]||[0,0,1,1];
  let uvPairs=[[0,0],[1,0],[1,1],[0,1]];
  for(let j=0;j<6;j++){let id=ids[j],order=[0,1,2,0,2,3][j];verts.push(...points[id]);let q=uvPairs[order];uvs.push(r[0]+q[0]*(r[2]-r[0]),r[1]+q[1]*(r[3]-r[1]));}
 }
 if(!verts.length)return;
 gl.uniformMatrix4fv(matrixLoc,false,new Float32Array(mul(viewProj,m)));
 gl.uniform4fv(tintLoc,tint);gl.bindTexture(gl.TEXTURE_2D,texture||white);
 gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(verts),gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(posLoc);gl.vertexAttribPointer(posLoc,3,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,tb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(uvs),gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(uvLoc);gl.vertexAttribPointer(uvLoc,2,gl.FLOAT,false,0,0);gl.drawArrays(gl.TRIANGLES,0,verts.length/3);
}
function persp(fov,aspect,n,f){let k=1/Math.tan(fov/2);return [k/aspect,0,0,0,0,k,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0]}
let viewProj=I(),yaw=-.42,pitch=-.1,distance=5.2,playing=true,animTime=0,speed=1,only=false,cosmetics=[],skin=null,skinTexture=null,skinSize=[64,64];
const skinParts=[
 // coordinates in model pixels centered at player body, texture map front/back/left/right/top/bottom atlas
 {pos:[-4,0,-4],size:[8,8,8],base:[0,0],anchor:'head'},
 {pos:[-4,8,-2],size:[8,12,4],base:[16,16],anchor:'body'},
 {pos:[-8,8,-2],size:[4,12,4],base:[32,48],anchor:'left_arm'},
 {pos:[4,8,-2],size:[4,12,4],base:[40,16],anchor:'right_arm'},
 {pos:[-4,20,-2],size:[4,12,4],base:[16,48],anchor:'left_leg'},
 {pos:[0,20,-2],size:[4,12,4],base:[0,16],anchor:'right_leg'}
];
function skinUV(base,w,h,d,sz){let [u,v]=base,tw=sz[0],th=sz[1];const r=(x,y,dx,dy)=>[x/tw,y/th,(x+dx)/tw,(y+dy)/th];return [r(u+d,v+d,w,h),r(u+d+w+d,v+d,w,h),r(u,v+d,d,h),r(u+d+w,v+d,d,h),r(u+d,v,w,d),r(u+d+w,v,w,d)]}
function fallbackSkin(){let c=document.createElement('canvas');c.width=c.height=64;let ctx=c.getContext('2d');ctx.fillStyle='#ae8bb9';ctx.fillRect(0,0,64,64);ctx.fillStyle='#e5b48a';ctx.fillRect(0,0,32,16);ctx.fillStyle='#413342';ctx.fillRect(8,8,8,8);ctx.fillStyle='#46576b';ctx.fillRect(16,16,24,16);ctx.fillStyle='#303d56';ctx.fillRect(0,16,32,16);ctx.fillStyle='#506b88';ctx.fillRect(16,48,32,16);ctx.fillStyle='#aa987f';ctx.fillRect(40,16,16,16);return c}
function drawPlayer(root){const src=skin||fallbackSkin();if(!skinTexture)skinTexture=texFromImage(src);const slim=$('armStyle').value==='slim';for(let i=0;i<skinParts.length;i++){
 let p=skinParts[i],sz=p.size.slice(),pos=p.pos.slice(),base=p.base.slice();if(slim&&(i===2||i===3))sz[0]=3;
 if(skinSize[1]===32&&(i===2||i===4)){base=i===2?[40,16]:[0,16]}
 // body coordinate: head origin at -8 from torso pivot, torso center at [0,0,0]; bottom y positive
 let offsetY=-12;let model=mul(root,move(0,offsetY,0));
 drawBox(model,[pos[0]/16,pos[1]/16,pos[2]/16,...sz.map(x=>x/16)],skinTexture,skinUV(base,sz[0],sz[1],sz[2],skinSize));
 }}
function anchorMatrix(root,anchor){let anchorPos={head:[0,-.75,0],body:[0,0,0],left_arm:[-.375,0,0],right_arm:[.375,0,0],left_leg:[-.125,.75,0],right_leg:[.125,.75,0],world:[0,0,0]};return mul(root,move(...(anchorPos[anchor]||[0,0,0])))}
function keyValue(tr,t){const keys=tr.keys,d=tr.duration||4.8;if(!keys?.length)return 0;let time=((t%d)+d)%d;if(time<=keys[0][0])return keys[0][1];for(let k=1;k<keys.length;k++)if(time<=keys[k][0]){let a=keys[k-1],b=keys[k],p=(time-a[0])/(b[0]-a[0]);if(tr.interpolation==='step')p=0;else if(tr.interpolation==='smooth')p=p*p*(3-2*p);return a[1]+(b[1]-a[1])*p}return keys[keys.length-1][1]}
function renderCosmetic(c,root){const transforms={};let packageAnchor=anchorMatrix(root,c.meta.attachTo);for(let part of c.parts){let vals={};for(let tr of c.channels[part.id]||[])vals[tr.property]=keyValue(tr,animTime);if(vals.visible!==undefined&&vals.visible<.5){transforms[part.id]=null;continue}
 let p=part.position,r=part.rotation,s=part.stretch||[1,1,1],v=part.offset||[0,0,0];let mm=chain(move((p[0]+(vals.offsetX||0))/16,(p[1]+(vals.offsetY||0))/16,(p[2]+(vals.offsetZ||0))/16),rz((r[2]+(vals.rotationZ||0))*rad),ry((r[1]+(vals.rotationY||0))*rad),rx((r[0]+(vals.rotationX||0))*rad),scale(s[0]*(1+(vals.scale||0)+(vals.scaleX||0)),s[1]*(1+(vals.scale||0)+(vals.scaleY||0)),s[2]*(1+(vals.scale||0)+(vals.scaleZ||0))));
 const parent=part.parent?transforms[part.parent]:packageAnchor;if(!parent){transforms[part.id]=null;continue}let model=mul(parent,mm);transforms[part.id]=model;
 let dims=part.size;if(dims.every(x=>x===0))continue;let t=c.textures[part.texture]||null;let uv=part.uv||[0,0,1,1];if(t&&part.textureFrames>1){let n=part.textureFrames,cols=part.textureColumns||1,frame=Math.floor(animTime/(part.frameSeconds||.3))%n,rows=Math.ceil(n/cols),cx=frame%cols,cy=Math.floor(frame/cols);uv=[(cx+uv[0])/cols,(cy+uv[1])/rows,(cx+uv[2])/cols,(cy+uv[3])/rows]}
 let color=part.color||'ffffff',colorVec=[0,2,4].map(idx=>parseInt(color.slice(idx,idx+2),16)/255);let r6=Array(6).fill(uv);const off=part.offset||[0,0,0];drawBox(model,[...off.map(x=>x/16),...dims.map(x=>x/16)],t,r6,[...colorVec,1]);
 }}
function updateCount(){$('count').textContent=cosmetics.filter(x=>x.active).length+' aktiv'}
function redrawList(){let el=$('items');el.innerHTML='';for(let c of cosmetics){let wrap=document.createElement('div');wrap.className='item';let img=document.createElement('img');img.src=c.icon||'';img.alt='';wrap.append(img);let info=document.createElement('div');info.className='item-info';let b=document.createElement('b');b.textContent=c.meta.name;let small=document.createElement('small');small.textContent=c.meta.slot+' · '+c.parts.length+' Teile';info.append(b,small);wrap.append(info);let checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=c.active;checkbox.title='Cosmetic anzeigen';checkbox.onchange=()=>{c.active=checkbox.checked;updateCount()};wrap.append(checkbox);let btn=document.createElement('button');btn.className='remove';btn.textContent='×';btn.title='Aus Viewer entfernen';btn.onclick=()=>{cosmetics=cosmetics.filter(x=>x!==c);Object.values(c.textures).forEach(t=>gl.deleteTexture(t));redrawList()};wrap.append(btn);el.append(wrap)}if(!cosmetics.length)el.innerHTML='<div class="no-items">Noch keine Cosmetics geladen</div>';updateCount()}
async function loadCosmetic(bytes,name){if(bytes.byteLength>16*1024*1024)throw Error('Datei größer als 16 MiB');const zip=await JSZip.loadAsync(bytes);let forbidden=Object.keys(zip.files).some(n=>n.startsWith('/')||n.split('/').includes('..'));if(forbidden)throw Error('Ungültiger ZIP-Pfad');let extract=async n=>{if(!zip.file(n))throw Error(n+' fehlt');return JSON.parse(await zip.file(n).async('string'))};let meta=await extract('cosmetic.json'),model=await extract('model.json'),anim=await extract('animations.json');if(![1,2].includes(meta.formatVersion)||!Array.isArray(model.parts)||model.parts.length>512)throw Error('Nicht unterstütztes Modellformat');if(!['body','head','left_arm','right_arm','left_leg','right_leg','world'].includes(meta.attachTo))throw Error('Unbekannter Anker');let textures={},icon=null;const texFiles=new Set(model.parts.map(p=>p.texture).filter(Boolean));for(let path of texFiles){if(!/^textures\/[\w-]+\.png$/.test(path)||!zip.file(path))throw Error('Textur fehlt: '+path);let blob=await zip.file(path).async('blob');let im=await imageFromBlob(blob);if(im.width>2048||im.height>2048)throw Error('Textur zu groß');textures[path]=texFromImage(im)}if(zip.file('icon.png')){let bytes=await zip.file('icon.png').async('uint8array');icon=URL.createObjectURL(new Blob([bytes],{type:'image/png'}))}
 let channels={};for(let tr of anim.tracks||[]){(channels[tr.target]??=[]).push({...tr,duration:anim.durationSeconds})}
 let obj={meta,parts:model.parts,channels,textures,icon,active:true};cosmetics.push(obj);redrawList();status('Geladen: '+meta.name);return obj}
$('cosInput').onchange=async e=>{for(let file of e.target.files){try{await loadCosmetic(await file.arrayBuffer(),file.name)}catch(err){status(file.name+': '+err.message)}}e.target.value=''};
// iOS: use UIDocumentPicker for the custom .cosmetic extension. The ordinary
// browser input remains available when running the same viewer as a PWA.
$('cosmeticUploadButton').onclick=()=>{
 if(window.webkit?.messageHandlers?.pickCosmetics){
  window.webkit.messageHandlers.pickCosmetics.postMessage('open');
 }else $('cosInput').click();
};
window.UViewerNativeImport={
 name:'',chunks:[],
 begin(name){this.name=name;this.chunks=[];status('Importiere '+name+' ...')},
 append(base64){this.chunks.push(base64)},
 async finish(){
  const name=this.name, encoded=this.chunks.join('');this.chunks=[];
  try{
   const decoded=atob(encoded),bytes=new Uint8Array(decoded.length);
   for(let i=0;i<decoded.length;i++)bytes[i]=decoded.charCodeAt(i);
   await loadCosmetic(bytes.buffer,name);
   status(name+' importiert');
  }catch(err){status(name+': '+err.message)}
 },
 error(message){status(message)}
};

async function installSkin(blob,name){
 const img=await imageFromBlob(blob);
 // Minecraft supports 64x64 (modern) and 64x32 (legacy), and HD multiples.
 if(img.width<64||img.width>1024||img.width%64!==0||![img.width,img.width/2].includes(img.height))
   throw Error('Skin muss 64×64 oder 64×32 Pixel bzw. ein HD-Vielfaches davon haben');
 const newTexture=texFromImage(img);
 if(skinTexture)gl.deleteTexture(skinTexture);
 skin=img;skinSize=[64,img.height===img.width?64:32];skinTexture=newTexture;
 $('skinName').textContent='Aktiv: '+name+' ('+img.width+'×'+img.height+')';
 $('skinPreview').src=URL.createObjectURL(blob);
 $('skinPreview').hidden=false;
 only=false;$('modePlayer').classList.add('active');$('modeOnly').classList.remove('active');
 yaw=-.42;pitch=-.1;distance=4.2;
 status('Skin geladen und Spieleransicht aktiviert: '+name);
}
$('skinInput').onchange=async e=>{
 const f=e.target.files[0];if(!f)return;
 try{await installSkin(f,f.name)}catch(err){status('Skin-Fehler: '+err.message)}
 e.target.value='';
};
$('skinUploadButton').onclick=()=>{
 if(window.webkit?.messageHandlers?.pickSkin)window.webkit.messageHandlers.pickSkin.postMessage('open');
 else $('skinInput').click();
};
window.UViewerNativeSkin={
 name:'',chunks:[],
 begin(name){this.name=name;this.chunks=[];status('Skin wird geladen: '+name)},
 append(chunk){this.chunks.push(chunk)},
 async finish(){
  const name=this.name,encoded=this.chunks.join('');this.chunks=[];
  try{
   const binary=atob(encoded),bytes=new Uint8Array(binary.length);
   for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
   await installSkin(new Blob([bytes],{type:'image/png'}),name);
  }catch(err){status('Skin-Fehler: '+err.message)}
 }
};
async function example(path){try{status('Beispiel wird geladen ...');let res=await fetch('examples/'+path);if(!res.ok)throw Error('Beispiel nicht abrufbar');await loadCosmetic(await res.arrayBuffer(),path)}catch(e){status('Beispiel: '+e.message+' – zum Test bitte über einen lokalen Webserver öffnen')}}
$('demoWings').onclick=()=>example('StreetTag-Wings-V6.cosmetic');$('demoHead').onclick=()=>example('Graffiti-Kopfband-A.cosmetic');
$('play').onclick=()=>{playing=!playing;$('play').textContent=playing?'Ⅱ Pause':'▶ Abspielen'};
$('speed').oninput=e=>{speed=Number(e.target.value);$('speedValue').textContent=speed.toFixed(1).replace('.',',')+'×'};
$('timeline').oninput=e=>{playing=false;$('play').textContent='▶ Abspielen';animTime=Number(e.target.value)/1000*4.8};
$('modePlayer').onclick=()=>{only=false;$('modePlayer').classList.add('active');$('modeOnly').classList.remove('active')};
$('modeOnly').onclick=()=>{only=true;$('modeOnly').classList.add('active');$('modePlayer').classList.remove('active')};
$('zoomIn').onclick=()=>distance=Math.max(2,distance-.45);$('zoomOut').onclick=()=>distance=Math.min(16,distance+.45);$('reset').onclick=()=>{distance=5.2;yaw=-.42;pitch=-.1};
$('shot').onclick=()=>{render();let png=$('scene').toDataURL('image/png');if(window.webkit?.messageHandlers?.shareScreenshot){window.webkit.messageHandlers.shareScreenshot.postMessage(png)}else{let a=document.createElement('a');a.href=png;a.download='u-cosmetic-viewer.png';a.click()}};
let activePointers=new Map(),pinch=0;
const canvas=$('scene');canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);activePointers.set(e.pointerId,[e.clientX,e.clientY])});
canvas.addEventListener('pointermove',e=>{if(!activePointers.has(e.pointerId))return;let old=activePointers.get(e.pointerId),dx=e.clientX-old[0],dy=e.clientY-old[1];activePointers.set(e.pointerId,[e.clientX,e.clientY]);if(activePointers.size===1){yaw+=dx*.01;pitch=Math.max(-1.4,Math.min(1.4,pitch+dy*.01))}else{let arr=[...activePointers.values()];let d=Math.hypot(arr[0][0]-arr[1][0],arr[0][1]-arr[1][1]);if(pinch)distance=Math.max(2,Math.min(16,distance*pinch/d));pinch=d}});
const pointerEnd=e=>{activePointers.delete(e.pointerId);pinch=0};canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);canvas.addEventListener('wheel',e=>{e.preventDefault();distance=Math.max(2,Math.min(16,distance+e.deltaY*.005))},{passive:false});
function render(){if(!gl)return;let w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(2,window.devicePixelRatio||1);if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(.065,.08,.11,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);let aspect=canvas.width/canvas.height;
 // Orbit: model center at chest (0,0,0); camera 5 blocks away
 viewProj=chain(persp(.78,aspect,.05,100),move(0,0,-distance),rx(pitch),ry(yaw));
 let root=scale(1,-1,1); // cosmetic Y down converted to WebGL Y up
 if(!only)drawPlayer(root);
 for(let c of cosmetics)if(c.active)renderCosmetic(c,root);
}
let last=performance.now();function tick(now){let dt=Math.min(.06,(now-last)/1000);last=now;if(playing)animTime+=dt*speed;let dur=cosmetics.find(c=>c.active)?.channels?4.8:4.8;$('timeline').value=((animTime%dur)/dur)*1000;$('elapsed').textContent=(animTime%dur).toFixed(1)+' s';render();requestAnimationFrame(tick)}requestAnimationFrame(tick);
