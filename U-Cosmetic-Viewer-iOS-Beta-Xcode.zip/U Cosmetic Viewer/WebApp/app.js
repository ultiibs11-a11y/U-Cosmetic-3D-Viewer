'use strict';
const $=id=>document.getElementById(id), rad=Math.PI/180;
const status=s=>{$('status').textContent=s};
const I=()=>[1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1];
function mul(a,b){const r=new Array(16).fill(0);for(let c=0;c<4;c++)for(let row=0;row<4;row++)for(let k=0;k<4;k++)r[c*4+row]+=a[k*4+row]*b[c*4+k];return r}
const move=(x,y,z)=>{let m=I();m[12]=x;m[13]=y;m[14]=z;return m};
const scale=(x,y,z)=>{let m=I();m[0]=x;m[5]=y;m[10]=z;return m};
const rx=a=>{let m=I(),c=Math.cos(a),s=Math.sin(a);m[5]=c;m[6]=s;m[9]=-s;m[10]=c;return m};
const ry=a=>{let m=I(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[2]=-s;m[8]=s;m[10]=c;return m};
const rz=a=>{let m=I(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[1]=s;m[4]=-s;m[5]=c;return m};
const chain=(...mats)=>mats.reduce(mul,I());
const gl=$('scene').getContext('webgl',{alpha:false,antialias:true,preserveDrawingBuffer:true});
if(!gl)status('WebGL ist in diesem Browser nicht verfügbar.');
const VS='attribute vec3 pos;attribute vec2 tex;uniform mat4 mvp;varying vec2 uv;void main(){gl_Position=mvp*vec4(pos,1.);uv=tex;}';
const FS='precision mediump float;uniform sampler2D image;uniform vec4 tint;varying vec2 uv;void main(){vec4 c=texture2D(image,uv)*tint;if(c.a<0.05)discard;gl_FragColor=c;}';
function shader(type,src){let s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
let program;if(gl){program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,VS));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,FS));gl.linkProgram(program);gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);}
const posLoc=gl?.getAttribLocation(program,'pos'),uvLoc=gl?.getAttribLocation(program,'tex'),matrixLoc=gl?.getUniformLocation(program,'mvp'),tintLoc=gl?.getUniformLocation(program,'tint');
const vb=gl?.createBuffer(),tb=gl?.createBuffer();let white;
function texFromImage(img,flipY=true){let t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,flipY);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);return t}
if(gl){let c=document.createElement('canvas');c.width=c.height=1;(()=>{let cx=c.getContext('2d');cx.fillStyle='#ffffff';cx.fillRect(0,0,1,1)})();white=texFromImage(c)}
function imageFromBlob(blob){return new Promise((ok,no)=>{let url=URL.createObjectURL(blob),im=new Image();im.onload=()=>{URL.revokeObjectURL(url);ok(im)};im.onerror=()=>{URL.revokeObjectURL(url);no(Error('PNG konnte nicht geöffnet werden'))};im.src=url})}
const faceIndices=[[4,5,6,4,6,7],[1,0,3,1,3,2],[0,4,7,0,7,3],[5,1,2,5,2,6],[3,7,6,3,6,2],[0,1,5,0,5,4]];
// 0 front (+Z), 1 back, 2 left, 3 right, 4 top, 5 bottom
function drawBox(m,ext,texture,rects,tint=[1,1,1,1],mirrorX=false,flipV=false){
 let [x,y,z,w,h,d]=ext;if(w===0&&h===0&&d===0)return;
 const xx=x+w,yy=y+h,zz=z+d;
 let points=[[x,y,z],[xx,y,z],[xx,yy,z],[x,yy,z],[x,y,zz],[xx,y,zz],[xx,yy,zz],[x,yy,zz]];
 let verts=[],uvs=[];
 for(let face=0;face<6;face++){
  // Flat parts: render only perpendicular faces, unless three dimensions nonzero
  // A zero-thickness plane is two-sided already (face culling is off).
  // Drawing both coincident faces causes double alpha and depth artifacts.
  if((d===0&&face!==0)||(w===0&&face!==2)||(h===0&&face!==4))continue;
  let ids=faceIndices[face],srcFace=mirrorX?(face===2?3:face===3?2:face):face,r=rects[srcFace]||rects[0]||[0,0,1,1];
  let uvPairs=[[0,0],[1,0],[1,1],[0,1]];
  for(let j=0;j<6;j++){let id=ids[j],order=[0,1,2,0,2,3][j];verts.push(...points[id]);let q=uvPairs[order];uvs.push(r[0]+(mirrorX?1-q[0]:q[0])*(r[2]-r[0]),r[1]+(flipV?1-q[1]:q[1])*(r[3]-r[1]));}
 }
 if(!verts.length)return;
 gl.uniformMatrix4fv(matrixLoc,false,new Float32Array(mul(viewProj,m)));
 gl.uniform4fv(tintLoc,tint);gl.bindTexture(gl.TEXTURE_2D,texture||white);
 gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(verts),gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(posLoc);gl.vertexAttribPointer(posLoc,3,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,tb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(uvs),gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(uvLoc);gl.vertexAttribPointer(uvLoc,2,gl.FLOAT,false,0,0);gl.drawArrays(gl.TRIANGLES,0,verts.length/3);
}
function persp(fov,aspect,n,f){let k=1/Math.tan(fov/2);return [k/aspect,0,0,0,0,k,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0]}
let viewProj=I(),yaw=-.42,pitch=-.1,distance=5.2,playing=true,animTime=0,speed=1,only=false,cosmetics=[],skin=null,skinTexture=null,skinSize=[64,64];
// Minecraft Java skin atlas. Coordinates are top-left pixel coordinates.
// The front of the player faces +Z in this viewer. UVs are sampled top-down,
// matching the PNG itself (UNPACK_FLIP_Y_WEBGL=false).
const skinParts=[
 {name:'head',   pos:[-4, 0,-4],size:[8, 8,8],base:[ 0, 0],outer:[32, 0]},
 {name:'body',   pos:[-4, 8,-2],size:[8,12,4],base:[16,16],outer:[16,32]},
 {name:'rightArm',pos:[ 4, 8,-2],size:[4,12,4],base:[40,16],outer:[40,32]},
 {name:'leftArm', pos:[-8, 8,-2],size:[4,12,4],base:[32,48],outer:[48,48]},
 {name:'rightLeg',pos:[ 0,20,-2],size:[4,12,4],base:[ 0,16],outer:[ 0,32]},
 {name:'leftLeg', pos:[-4,20,-2],size:[4,12,4],base:[16,48],outer:[ 0,48]}
];
function skinUV(base,w,h,d,sz){
 const [u,v]=base,tw=sz[0],th=sz[1];
 const r=(x,y,dx,dy)=>[x/tw,y/th,(x+dx)/tw,(y+dy)/th];
 return [
  r(u+d,v+d,w,h),       // front (+Z)
  r(u+2*d+w,v+d,w,h),   // back (-Z)
  r(u,v+d,d,h),         // left (-X)
  r(u+d+w,v+d,d,h),     // right (+X)
  // drawPlayer uses root=scale(1,-1,1). The cube's local +Y face
  // therefore becomes the physical BOTTOM; local -Y becomes TOP.
  // drawBox face order is [+Z,-Z,-X,+X,+Y,-Y].
  r(u+d+w,v,w,d),       // local +Y => physical bottom
  r(u+d,v,w,d)          // local -Y => physical top
 ];
}
let fallbackSkinCanvas=null;
function fallbackSkin(){if(fallbackSkinCanvas)return fallbackSkinCanvas;let c=document.createElement('canvas');c.width=c.height=64;let ctx=c.getContext('2d');ctx.fillStyle='#ae8bb9';ctx.fillRect(0,0,64,64);ctx.fillStyle='#e5b48a';ctx.fillRect(0,0,32,16);ctx.fillStyle='#413342';ctx.fillRect(8,8,8,8);ctx.fillStyle='#46576b';ctx.fillRect(16,16,24,16);ctx.fillStyle='#303d56';ctx.fillRect(0,16,32,16);ctx.fillStyle='#506b88';ctx.fillRect(16,48,32,16);ctx.fillStyle='#aa987f';ctx.fillRect(40,16,16,16);fallbackSkinCanvas=c;return c}
function drawPlayer(root){
 const src=skin||fallbackSkin();
 if(!skinTexture)skinTexture=texFromImage(src,false);
 const slim=$('armStyle').value==='slim', legacy=skinSize[1]===32;
 // Model coordinates are Minecraft pixels: head 0..8, torso 8..20, legs 20..32.
 // Center the whole player around the orbit target, 16 px = 1 world unit.
 const model=mul(root,move(0,-16/16,0));
 for(const p of skinParts){
  let sz=p.size.slice(),pos=p.pos.slice(),base=p.base;
  if(slim&&(p.name==='rightArm'||p.name==='leftArm')){
   sz[0]=3;
   if(p.name==='leftArm')pos[0]=-7;
  }
  // Legacy skins (64x32) share the right limb textures on the left limbs.
  // Mirroring legacy UVs requires separate handling; see skinUVForPart below.
  if(legacy){
   if(p.name==='leftArm')base=[40,16];
   if(p.name==='leftLeg')base=[0,16];
  }
  const ext=[...pos.map(v=>v/16),...sz.map(v=>v/16)];
  drawBox(model,ext,skinTexture,skinUV(base,sz[0],sz[1],sz[2],skinSize),[1,1,1,1],legacy&&(p.name==='leftArm'||p.name==='leftLeg'));
  if(!legacy||p.name==='head'){
   // Outer hat, jacket, sleeves and trouser layers are separate transparent
   // cuboids, expanded by half a Minecraft pixel on every side.
   const expansion=p.name==='head'?0.5:0.25;
   const expanded=[(pos[0]-expansion)/16,(pos[1]-expansion)/16,(pos[2]-expansion)/16,
    (sz[0]+2*expansion)/16,(sz[1]+2*expansion)/16,(sz[2]+2*expansion)/16];
   drawBox(model,expanded,skinTexture,skinUV(p.outer,sz[0],sz[1],sz[2],skinSize));
  }
 }
}
// Minecraft cosmetic coordinates: +Y is down, +Z points BEHIND the player.
// The WebGL skin faces +Z, so the cosmetic root mirrors both Y and Z.
// Anchors refer to the top pivot of the corresponding Minecraft body part.
function anchorMatrix(root,anchor){
 // Minecraft model pivots are at the NECK for both head and body, 8 pixels
 // below the top of the head (the skin is centered 16 pixels below that top).
 // Previously head used -16 here, lifting all head cosmetics by 8 pixels.
 // Cosmetic positions are relative to the matching body-part pivot.
 const pivots={head:[0,-8,0],body:[0,-8,0],left_arm:[-6,-8,0],right_arm:[6,-8,0],left_leg:[-2,4,0],right_leg:[2,4,0],world:[0,0,0]};
 const a=pivots[anchor]||pivots.world;
 return mul(root,move(a[0]/16,a[1]/16,a[2]/16));
}
function keyValue(tr,t){
 const keys=tr.keys,d=tr.duration||4.8;if(!keys?.length)return 0;
 let time=((t%d)+d)%d;
 if(time<=keys[0][0])return keys[0][1];
 for(let k=1;k<keys.length;k++)if(time<=keys[k][0]){
  let a=keys[k-1],b=keys[k],p=(time-a[0])/(b[0]-a[0]);
  if(tr.interpolation==='step')p=0;
  else if(!tr.interpolation||tr.interpolation==='smooth')p=p*p*(3-2*p);
  return a[1]+(b[1]-a[1])*p;
 }
 return keys[keys.length-1][1];
}
function transformPoint(m,x,y,z){return [m[0]*x+m[4]*y+m[8]*z+m[12],m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14]]}
function boxCorners(m,ext){
 let [x,y,z,w,h,d]=ext,arr=[];
 for(let a of [x,x+w])for(let b of [y,y+h])for(let c of [z,z+d])arr.push(transformPoint(m,a,b,c));
 return arr;
}
function cosmeticCommands(c,root,t=animTime){
 const transforms=new Map(),commands=[];
 const packageAnchor=anchorMatrix(root,c.meta.attachTo);
 // Imported model parts may be unordered. Validation guarantees no cycles.
 const visit=(part)=>{
  if(transforms.has(part.id))return transforms.get(part.id);
  const parent=part.parent?c.partById.get(part.parent):null;
  const pm=parent?visit(parent):packageAnchor;
  if(!pm){transforms.set(part.id,null);return null}
  const vals={};for(let tr of c.channels[part.id]||[])vals[tr.property]=keyValue(tr,t);
  if(vals.visible!==undefined&&vals.visible<.5){transforms.set(part.id,null);return null}
  const p=part.position,r=part.rotation,st=part.stretch||[1,1,1];
  const m=chain(move((p[0]+(vals.offsetX||0))/16,(p[1]+(vals.offsetY||0))/16,(p[2]+(vals.offsetZ||0))/16),
   rz((r[2]+(vals.rotationZ||0))*rad),ry((r[1]+(vals.rotationY||0))*rad),rx((r[0]+(vals.rotationX||0))*rad),
   scale(st[0]*(1+(vals.scale||0)+(vals.scaleX||0)),st[1]*(1+(vals.scale||0)+(vals.scaleY||0)),st[2]*(1+(vals.scale||0)+(vals.scaleZ||0))));
  const world=mul(pm,m);transforms.set(part.id,world);return world;
 };
 for(let part of c.parts){
  const model=visit(part);if(!model||part.size.every(v=>v===0))continue;
  let uv=part.uv||[0,0,1,1];
  if(part.textureFrames>1){
   const n=part.textureFrames,cols=part.textureColumns||1,rows=Math.ceil(n/cols);
   const frame=Math.floor(t/(part.frameSeconds||.3))%n;
   const cx=frame%cols,cy=Math.floor(frame/cols);
   uv=[(cx+uv[0])/cols,(cy+uv[1])/rows,(cx+uv[2])/cols,(cy+uv[3])/rows];
  }
  const color=part.color||'ffffff',colorVec=[0,2,4].map(i=>parseInt(color.slice(i,i+2),16)/255);
  const ext=[...(part.offset||[0,0,0]).map(x=>x/16),...part.size.map(x=>x/16)];
  const corners=boxCorners(model,ext);
  const center=corners.reduce((a,b)=>a.map((v,i)=>v+b[i]/corners.length),[0,0,0]);
  commands.push({model,ext,texture:c.textures[part.texture]||null,uv,tint:[...colorVec,1],corners,center});
 }
 return commands;
}
function renderCosmetics(root){
 const all=[];
 for(let c of cosmetics)if(c.active)all.push(...cosmeticCommands(c,root));
 // Sort blended sprites back-to-front in view space; depth buffer remains
 // readable for the player, but transparent pixels never block later layers.
 all.sort((a,b)=>transformPoint(cameraView,...a.center)[2]-transformPoint(cameraView,...b.center)[2]);
 gl.depthMask(false);
 for(let cmd of all)drawBox(cmd.model,cmd.ext,cmd.texture,Array(6).fill(cmd.uv),cmd.tint);
 gl.depthMask(true);
}
function sceneBounds(root){
 // Streaming bounds: never keep hundreds of thousands of corner arrays in
 // memory or spread them into Math.max (which can overflow JS argument limits).
 const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
 const include=p=>{for(let i=0;i<3;i++){lo[i]=Math.min(lo[i],p[i]);hi[i]=Math.max(hi[i],p[i]);}};
 if(!only)for(let x of [-.5,.5])for(let y of [-1,1])for(let z of [-.3,.3])include([x,y,z]);
 for(let c of cosmetics)if(c.active){
  // Include authored keyframes, plus regular samples to catch smooth motion.
  const times=new Set([0,c.duration/4,c.duration/2,c.duration*3/4]);
  for(const tracks of Object.values(c.channels))for(const tr of tracks)
   for(const k of tr.keys)times.add(k[0]);
  const sorted=[...times].sort((a,b)=>a-b);
  const sample=sorted.length>48?Array.from({length:48},(_,i)=>c.duration*i/48):sorted;
  for(const t of sample)for(const cmd of cosmeticCommands(c,root,t))for(const p of cmd.corners)include(p);
 }
 if(!Number.isFinite(lo[0]))return {center:[0,0,0],radius:1.5};
 const center=lo.map((v,i)=>(v+hi[i])/2);
 const radius=Math.max(1.25,Math.hypot(...hi.map((v,i)=>v-lo[i]))/2);
 return {center,radius};
}
function updateCount(){$('count').textContent=cosmetics.filter(x=>x.active).length+' aktiv'}
function redrawList(){let el=$('items');el.innerHTML='';for(let c of cosmetics){let wrap=document.createElement('div');wrap.className='item';let img=document.createElement('img');img.src=c.icon||'';img.alt='';wrap.append(img);let info=document.createElement('div');info.className='item-info';let b=document.createElement('b');b.textContent=c.meta.name;let small=document.createElement('small');small.textContent=c.meta.slot+' · '+c.parts.length+' Teile';info.append(b,small);
 wrap.append(info);let checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=c.active;checkbox.title='Cosmetic anzeigen';checkbox.onchange=()=>{c.active=checkbox.checked;updateCount();autoFitCamera()};wrap.append(checkbox);let btn=document.createElement('button');btn.className='remove';btn.textContent='×';btn.title='Aus Viewer entfernen';btn.onclick=()=>{cosmetics=cosmetics.filter(x=>x!==c);Object.values(c.textures).forEach(t=>gl.deleteTexture(t));if(c.icon)URL.revokeObjectURL(c.icon);redrawList();autoFitCamera()};wrap.append(btn);el.append(wrap)}if(!cosmetics.length)el.innerHTML='<div class="no-items">Noch keine Cosmetics geladen</div>';updateCount()}
const validVector=(v,n=3)=>Array.isArray(v)&&v.length===n&&v.every(x=>typeof x==='number'&&Number.isFinite(x)&&Math.abs(x)<10000);
function validateCosmetic(meta,model,anim,zip){
 if(!meta||![1,2].includes(meta.formatVersion)||typeof meta.name!=='string'||!meta.name.trim()||meta.name.length>64||!(/^[a-z0-9_-]{3,64}$/).test(meta.id)||!['back','head','arms','legs','aura'].includes(meta.slot))throw Error('Ungültige cosmetic.json');
 if(!['body','head','left_arm','right_arm','left_leg','right_leg','world'].includes(meta.attachTo))throw Error('Unbekannter Modellanker');
 if(!model||!Array.isArray(model.parts)||model.parts.length<1||model.parts.length>512)throw Error('Modell hat zu viele Teile');
 if(!anim||!Array.isArray(anim.tracks)||anim.tracks.length>256||!(anim.durationSeconds>0&&anim.durationSeconds<=120))throw Error('Ungültige Animation');
 const ids=new Set();
 for(const part of model.parts){
  if(typeof part.id!=='string'||ids.has(part.id)||!(/^[A-Za-z0-9_-]{1,64}$/).test(part.id))throw Error('Doppelte oder ungültige Modellteil-ID');
  ids.add(part.id);
  if(!validVector(part.position)||!validVector(part.rotation)||!validVector(part.size)||!validVector(part.offset||[0,0,0])||!validVector(part.stretch||[1,1,1]))throw Error('Ungültige Modellkoordinaten: '+part.id);
  if([...part.position,...part.size,...(part.offset||[0,0,0])].some(x=>Math.abs(x)>256)||part.size.some(x=>x<0)||part.rotation.some(x=>Math.abs(x)>720)||part.stretch?.some(x=>x<=0))throw Error('Ungültige Modellgröße');
  if(part.uv&&(!validVector(part.uv,4)||part.uv.some(x=>x<0||x>1)))throw Error('Ungültige UV-Koordinaten');
  if(part.color&&!/^[0-9a-fA-F]{6}$/.test(part.color))throw Error('Ungültiger Farbwert');
  if(part.texture&&(!/^textures\/[\w-]+\.png$/.test(part.texture)||!zip.file(part.texture)))throw Error('Textur fehlt: '+part.texture);
  if(part.textureFrames!==undefined&&(!Number.isInteger(part.textureFrames)||part.textureFrames<1||part.textureFrames>64))throw Error('Ungültige Frame-Anzahl');
  if(part.textureColumns!==undefined&&(!Number.isInteger(part.textureColumns)||part.textureColumns<1||part.textureColumns>8))throw Error('Ungültige Frame-Spalten');
  if(part.frameSeconds!==undefined&&(!(part.frameSeconds>=.05)||part.frameSeconds>120))throw Error('Ungültige Frame-Geschwindigkeit');
 }
 const byId=new Map(model.parts.map(p=>[p.id,p]));
 const visited=new Set(),visiting=new Set();
 const walk=id=>{if(visiting.has(id))throw Error('Zyklische Modellhierarchie');if(visited.has(id))return;
  visiting.add(id);const p=byId.get(id);if(p.parent){if(!byId.has(p.parent))throw Error('Fehlender Modell-Elternteil');walk(p.parent)}visiting.delete(id);visited.add(id)};
 for(let id of ids)walk(id);
 for(let tr of anim.tracks){
  if(tr.interpolation&&!['linear','smooth','step'].includes(tr.interpolation))throw Error('Ungültige Interpolation');
  if(!ids.has(tr.target)||!['rotationX','rotationY','rotationZ','offsetX','offsetY','offsetZ','scale','scaleX','scaleY','scaleZ','visible'].includes(tr.property)||!Array.isArray(tr.keys)||tr.keys.length<2||tr.keys.length>256)throw Error('Ungültiges Animationsziel');
  let last=-Infinity;
  for(let k of tr.keys){if(!validVector(k,2)||k[0]<=last||k[0]<0||k[0]>anim.durationSeconds||Math.abs(k[1])>360)throw Error('Ungültige Animations-Keyframes');last=k[0]}
 }
 return byId;
}
async function loadCosmetic(bytes,name){
 if(bytes.byteLength>16*1024*1024)throw Error('Datei größer als 16 MiB');
 const zip=await JSZip.loadAsync(bytes);
 const names=Object.keys(zip.files);
 if(names.length>128||names.filter(n=>!n.endsWith('/')).length>64||names.some(n=>n.startsWith('/')||n.includes('\\')||n.split('/').includes('..')||(!n.endsWith('/')&&!['cosmetic.json','model.json','animations.json','icon.png'].includes(n)&&!/^textures\/[\w-]+\.png$/.test(n))))throw Error('Ungültiger ZIP-Inhalt');
 const total=names.reduce((s,n)=>s+(zip.files[n]._data?.uncompressedSize||0),0);
 if(total>32*1024*1024||names.some(n=>(zip.files[n]._data?.uncompressedSize||0)>8*1024*1024))throw Error('Cosmetic entpackt zu groß');
 const extract=async n=>{if(!zip.file(n))throw Error(n+' fehlt');const str=await zip.file(n).async('string');if(str.length>2*1024*1024)throw Error(n+' zu groß');return JSON.parse(str)};
 const meta=await extract('cosmetic.json'),model=await extract('model.json'),anim=await extract('animations.json');
 const partById=validateCosmetic(meta,model,anim,zip);
 const textures={},created=[];let icon=null;
 try{
  const texFiles=new Set(model.parts.map(p=>p.texture).filter(Boolean));
  for(let path of texFiles){
   const blob=await zip.file(path).async('blob');
   if(blob.size>16*1024*1024)throw Error('Texturdatei zu groß');
   const im=await imageFromBlob(blob);
   if(im.width>2048||im.height>2048||im.width<1||im.height<1)throw Error('Texturabmessungen ungültig');
   const t=texFromImage(im,true);textures[path]=t;created.push(t);
  }
  if(zip.file('icon.png')){
   const data=await zip.file('icon.png').async('uint8array');
   if(data.length<=1024*1024)icon=URL.createObjectURL(new Blob([data],{type:'image/png'}));
  }
  const channels={};for(let tr of anim.tracks)(channels[tr.target]??=[]).push({...tr,duration:anim.durationSeconds});
  // Render exactly as authored: no hidden per-ID UV flips or model mirrors.
  // The file's coordinate system is authoritative for every imported cosmetic.
  const obj={meta,parts:model.parts,partById,channels,textures,icon,active:true,duration:anim.durationSeconds};
  const existing=cosmetics.findIndex(c=>c.meta.id===meta.id);
  if(existing>=0){const old=cosmetics[existing];Object.values(old.textures).forEach(t=>gl.deleteTexture(t));if(old.icon)URL.revokeObjectURL(old.icon);cosmetics[existing]=obj;}
  else cosmetics.push(obj);
  redrawList();autoFitCamera();status('Geladen: '+meta.name);return obj;
 }catch(e){for(let t of created)gl.deleteTexture(t);if(icon)URL.revokeObjectURL(icon);throw e}
}
$('cosInput').onchange=async e=>{for(let file of e.target.files){try{await loadCosmetic(await file.arrayBuffer(),file.name)}catch(err){status(file.name+': '+err.message)}}e.target.value=''};
// iOS: use UIDocumentPicker for the custom .cosmetic extension. The ordinary
// browser input remains available when running the same viewer as a PWA.
$('cosmeticUploadButton').onclick=()=>{
 if(window.webkit?.messageHandlers?.pickCosmetics){
  window.webkit.messageHandlers.pickCosmetics.postMessage('open');
 }else $('cosInput').click();
};
window.UViewerNativeImport={
 name:'',chunks:[],
 begin(name){this.name=name;this.chunks=[];status('Importiere '+name+' ...')},
 append(base64){this.chunks.push(base64)},
 async finish(){
  const name=this.name, encoded=this.chunks.join('');this.chunks=[];
  try{
   const decoded=atob(encoded),bytes=new Uint8Array(decoded.length);
   for(let i=0;i<decoded.length;i++)bytes[i]=decoded.charCodeAt(i);
   await loadCosmetic(bytes.buffer,name);
   status(name+' importiert');
  }catch(err){status(name+': '+err.message)}
 },
 error(message){status(message)}
};

async function installSkin(blob,name){
 const img=await imageFromBlob(blob);
 // Minecraft supports 64x64 (modern) and 64x32 (legacy), and HD multiples.
 if(img.width<64||img.width>1024||img.width%64!==0||![img.width,img.width/2].includes(img.height))
   throw Error('Skin muss 64×64 oder 64×32 Pixel bzw. ein HD-Vielfaches davon haben');
 const newTexture=texFromImage(img,false);
 if(skinTexture)gl.deleteTexture(skinTexture);
 skin=img;skinSize=[64,img.height===img.width?64:32];skinTexture=newTexture;
 $('skinName').textContent='Aktiv: '+name+' ('+img.width+'×'+img.height+')';
 if(window.skinPreviewURL)URL.revokeObjectURL(window.skinPreviewURL);
 window.skinPreviewURL=URL.createObjectURL(blob);$('skinPreview').src=window.skinPreviewURL;
 $('skinPreview').hidden=false;
 only=false;$('modePlayer').classList.add('active');$('modeOnly').classList.remove('active');
 yaw=-.42;pitch=-.1;autoFitCamera();
 status('Skin geladen und Spieleransicht aktiviert: '+name);
}
$('skinInput').onchange=async e=>{
 const f=e.target.files[0];if(!f)return;
 try{await installSkin(f,f.name)}catch(err){status('Skin-Fehler: '+err.message)}
 e.target.value='';
};
$('skinUploadButton').onclick=()=>{
 if(window.webkit?.messageHandlers?.pickSkin)window.webkit.messageHandlers.pickSkin.postMessage('open');
 else $('skinInput').click();
};
window.UViewerNativeSkin={
 name:'',chunks:[],
 begin(name){this.name=name;this.chunks=[];status('Skin wird geladen: '+name)},
 append(chunk){this.chunks.push(chunk)},
 async finish(){
  const name=this.name,encoded=this.chunks.join('');this.chunks=[];
  try{
   const binary=atob(encoded),bytes=new Uint8Array(binary.length);
   for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
   await installSkin(new Blob([bytes],{type:'image/png'}),name);
  }catch(err){status('Skin-Fehler: '+err.message)}
 }
};
async function example(path){try{status('Beispiel wird geladen ...');let res=await fetch('examples/'+path);if(!res.ok)throw Error('Beispiel nicht abrufbar');await loadCosmetic(await res.arrayBuffer(),path)}catch(e){status('Beispiel: '+e.message+' – zum Test bitte über einen lokalen Webserver öffnen')}}
$('demoWings').onclick=()=>example('StreetTag-Wings-V6.cosmetic');$('demoHead').onclick=()=>example('Graffiti-Kopfband-A.cosmetic');
$('play').onclick=()=>{playing=!playing;$('play').textContent=playing?'Ⅱ Pause':'▶ Abspielen'};
$('speed').oninput=e=>{speed=Number(e.target.value);$('speedValue').textContent=speed.toFixed(1).replace('.',',')+'×'};
$('timeline').oninput=e=>{playing=false;$('play').textContent='▶ Abspielen';animTime=Number(e.target.value)/1000*(cosmetics.find(c=>c.active)?.duration||4.8)};
$('modePlayer').onclick=()=>{only=false;$('modePlayer').classList.add('active');$('modeOnly').classList.remove('active');autoFitCamera()};
$('modeOnly').onclick=()=>{only=true;$('modeOnly').classList.add('active');$('modePlayer').classList.remove('active');autoFitCamera()};
$('zoomIn').onclick=()=>distance=Math.max(cameraMinDistance,distance-.45);$('zoomOut').onclick=()=>distance=Math.min(cameraMaxDistance,distance+.45);$('reset').onclick=()=>{yaw=-.42;pitch=-.1;autoFitCamera()};
$('shot').onclick=()=>{render();let png=$('scene').toDataURL('image/png');if(window.webkit?.messageHandlers?.shareScreenshot){window.webkit.messageHandlers.shareScreenshot.postMessage(png)}else{let a=document.createElement('a');a.href=png;a.download='u-cosmetic-viewer.png';a.click()}};
let activePointers=new Map(),pinch=0;
const canvas=$('scene');canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);activePointers.set(e.pointerId,[e.clientX,e.clientY])});
canvas.addEventListener('pointermove',e=>{if(!activePointers.has(e.pointerId))return;let old=activePointers.get(e.pointerId),dx=e.clientX-old[0],dy=e.clientY-old[1];activePointers.set(e.pointerId,[e.clientX,e.clientY]);if(activePointers.size===1){yaw+=dx*.01;pitch=Math.max(-1.4,Math.min(1.4,pitch+dy*.01))}else{let arr=[...activePointers.values()];let d=Math.hypot(arr[0][0]-arr[1][0],arr[0][1]-arr[1][1]);if(pinch)distance=Math.max(cameraMinDistance,Math.min(cameraMaxDistance,distance*pinch/d));pinch=d}});
const pointerEnd=e=>{activePointers.delete(e.pointerId);pinch=0};canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);canvas.addEventListener('wheel',e=>{e.preventDefault();distance=Math.max(cameraMinDistance,Math.min(cameraMaxDistance,distance+e.deltaY*.005))},{passive:false});
let cameraView=I(),cameraCenter=[0,0,0],cameraMinDistance=2,cameraMaxDistance=30;
function autoFitCamera(){
 if(!gl)return;
 const canvas=$('scene');
 const aspect=Math.max(.35,canvas.clientWidth/Math.max(1,canvas.clientHeight));
 const {center,radius}=sceneBounds(scale(1,-1,-1));
 cameraCenter=center;
 const vertical=.78/2,horizontal=Math.atan(Math.tan(vertical)*aspect);
 // Keep all parts in view on narrow iPhone screens, including wing tips.
 distance=Math.max(2,1.22*radius/Math.sin(Math.min(vertical,horizontal)));
 cameraMinDistance=Math.max(.8,distance*.32);
 cameraMaxDistance=Math.max(30,distance*3);
}
function render(){
 if(!gl)return;
 let w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(2,window.devicePixelRatio||1);
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}
 gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(.065,.08,.11,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 const aspect=canvas.width/canvas.height;
 cameraView=chain(move(0,0,-distance),rx(pitch),ry(yaw),move(-cameraCenter[0],-cameraCenter[1],-cameraCenter[2]));
 viewProj=mul(persp(.78,aspect,.05,100),cameraView);
 gl.depthMask(true);
 if(!only)drawPlayer(scale(1,-1,1));
 renderCosmetics(scale(1,-1,-1));
}
let last=performance.now();function tick(now){let dt=Math.min(.06,(now-last)/1000);last=now;if(playing)animTime+=dt*speed;let dur=cosmetics.find(c=>c.active)?.duration||4.8;$('timeline').value=((animTime%dur)/dur)*1000;$('elapsed').textContent=(animTime%dur).toFixed(1)+' s';render();requestAnimationFrame(tick)}requestAnimationFrame(tick);

// Frame the default player on startup (also handles portrait orientation).
requestAnimationFrame(()=>autoFitCamera());

window.addEventListener('resize',()=>autoFitCamera());
