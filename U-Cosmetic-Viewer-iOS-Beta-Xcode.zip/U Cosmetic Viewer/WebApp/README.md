# U Cosmetic 3D Viewer – Beta

Mobiler, browserbasierter Viewer für Minecraft-Skins und U-Cosmetic-Dateien (Format 1/2).

## Start

1. ZIP entpacken.
2. Im Ordner der `index.html` einen lokalen Webserver starten: `python3 -m http.server 8000`.
3. `http://localhost:8000` öffnen. Auf dem iPhone die Dateien über eine HTTPS-Website bereitstellen und die Seite in Safari öffnen. Unter „Teilen → Zum Home-Bildschirm“ lässt sie sich als Web-App hinzufügen.
4. Skin-PNG und `.cosmetic`-Dateien importieren. Alternativ integrierte Demo-Flügel und Kopfband laden.

Die Uploads verbleiben im Browser. Die Seite lädt keine Daten zu einem Server hoch.

## Unterstützt

3D-Modelle, Hierarchien, Texture-Spritesheets, Keyframe-Animationen, Kombination verschiedener Cosmetics, Drehen, Zoomen, Pause, Tempo und PNG-Screenshot. Alle Bibliotheken und Beispiel-Cosmetics sind beigelegt; keine externe CDN-Abhängigkeit.

## Beta-Einschränkungen

- Der 3D-Renderer ist eine eigenständige WebGL-Implementierung, kein exakter Minecraft-Renderer. Abweichungen von Skin-UVs, Ankern, Z-Sortierung und Oberflächenorientierung sind möglich.
- Die Skin-Darstellung ist derzeit vereinfacht, insbesondere bei Slim-Arm-UVs und den zweiten Skin-Layern.
- Die Animation-Zeitleiste basiert derzeit auf einem 4,8-Sekunden-Raster (passend zu den gelieferten V6-Beispielen).
- Hochauflösende animierte Cosmetics können auf älteren iPhones langsamer sein.
- Für Safari auf dem iPhone ist eine HTTPS-Adresse sinnvoll bzw. für dauerhaftes Installieren als Web-App notwendig. Es wird noch kein Hosting bereitgestellt.
- Importierte Dateien werden nicht dauerhaft gespeichert; beim Neuladen muss erneut importiert werden.
- Der Viewer führt keinen beliebigen Code aus importierten ZIP-Paketen aus. Er ist aber noch kein vollständig gehärteter Validator gegen absichtlich manipulierte ZIP-Dateien.


## Beta 0.10

Der HEAD-Anker liegt nun am Hals statt 8 Modellpixel zu hoch. V6-Texturen werden ohne pauschales Spiegeln aus der `.cosmetic`-Datei dargestellt. Automatischer Kamera-Fit umfasst Animations-Keyframes.
