import SwiftUI
import WebKit
import UIKit

struct ViewerWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "shareScreenshot")
        let config = WKWebViewConfiguration()
        config.userContentController = controller
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        let view = WKWebView(frame: .zero, configuration: config)
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 0.06, green: 0.075, blue: 0.105, alpha: 1)
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.scrollView.bounces = false
        view.scrollView.isScrollEnabled = true
        view.allowsBackForwardNavigationGestures = false
        view.navigationDelegate = context.coordinator
        context.coordinator.webView = view
        guard let page = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "WebApp"),
              let directory = Bundle.main.url(forResource: "WebApp", withExtension: nil) else {
            view.loadHTMLString("<h2>Viewer-Dateien fehlen</h2>", baseURL: nil)
            return view
        }
        view.loadFileURL(page, allowingReadAccessTo: directory)
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) { }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        weak var webView: WKWebView?
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "shareScreenshot",
                  let value = message.body as? String,
                  value.hasPrefix("data:image/png;base64,"),
                  let data = Data(base64Encoded: String(value.dropFirst("data:image/png;base64,".count))),
                  let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                      let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return }
                var top = root
                while let presented = top.presentedViewController { top = presented }
                let activity = UIActivityViewController(activityItems: [image], applicationActivities: nil)
                if let popover = activity.popoverPresentationController {
                    popover.sourceView = top.view
                    popover.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 1, height: 1)
                }
                top.present(activity, animated: true)
            }
        }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // External navigation is not part of this offline application.
            if let scheme = navigationAction.request.url?.scheme,
               !["file", "about", "blob", "data"].contains(scheme) {
                decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }
    }
}
