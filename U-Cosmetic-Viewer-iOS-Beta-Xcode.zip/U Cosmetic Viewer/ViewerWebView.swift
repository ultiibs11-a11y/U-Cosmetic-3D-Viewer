import SwiftUI
import WebKit
import UIKit
import UniformTypeIdentifiers

struct ViewerWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "shareScreenshot")
        controller.add(context.coordinator, name: "pickCosmetics")
        controller.add(context.coordinator, name: "pickSkin")
        controller.add(context.coordinator, name: "nativeImportDone")
        let config = WKWebViewConfiguration()
        config.userContentController = controller
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        let view = WKWebView(frame: .zero, configuration: config)
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 0.06, green: 0.075, blue: 0.105, alpha: 1)
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.scrollView.bounces = false
        view.scrollView.isScrollEnabled = true
        view.allowsBackForwardNavigationGestures = false
        view.navigationDelegate = context.coordinator
        context.coordinator.webView = view
        guard let page = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "WebApp"),
              let directory = Bundle.main.url(forResource: "WebApp", withExtension: nil) else {
            view.loadHTMLString("<h2>Viewer-Dateien fehlen</h2>", baseURL: nil)
            return view
        }
        view.loadFileURL(page, allowingReadAccessTo: directory)
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) { }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, UIDocumentPickerDelegate {
        weak var webView: WKWebView?
        private var pendingDocuments: [URL] = []
        private var pickingSkin = false

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            switch message.name {
            case "pickCosmetics":
                openCosmeticPicker()
            case "pickSkin":
                openSkinPicker()
            case "nativeImportDone":
                importNextDocument()
            case "shareScreenshot":
                guard let value = message.body as? String,
                      value.hasPrefix("data:image/png;base64,"),
                      let data = Data(base64Encoded: String(value.dropFirst("data:image/png;base64,".count))),
                      let image = UIImage(data: data) else { return }
                DispatchQueue.main.async {
                    guard let top = self.topViewController() else { return }
                    let activity = UIActivityViewController(activityItems: [image], applicationActivities: nil)
                    if let popover = activity.popoverPresentationController {
                        popover.sourceView = top.view
                        popover.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 1, height: 1)
                    }
                    top.present(activity, animated: true)
                }
            default: break
            }
        }

        private func topViewController() -> UIViewController? {
            guard let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
                  let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return nil }
            var top = root
            while let presented = top.presentedViewController { top = presented }
            return top
        }

        private func openCosmeticPicker() {
            DispatchQueue.main.async {
                self.pickingSkin = false
                guard let top = self.topViewController() else { return }
                // .cosmetic has no standard iOS UTType. Allow files of all types,
                // then validate extension and package contents in our importer.
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
                picker.delegate = self
                picker.allowsMultipleSelection = true
                picker.modalPresentationStyle = .formSheet
                top.present(picker, animated: true)
            }
        }

        private func openSkinPicker() {
            DispatchQueue.main.async {
                self.pickingSkin = true
                guard let top = self.topViewController() else { return }
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.png, .image], asCopy: true)
                picker.delegate = self
                picker.allowsMultipleSelection = false
                picker.modalPresentationStyle = .formSheet
                top.present(picker, animated: true)
            }
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if pickingSkin {
                pickingSkin = false
                if let url = urls.first { importSkinDocument(url) }
                return
            }
            pendingDocuments = urls
            importNextDocument()
        }

        private func importSkinDocument(_ url: URL) {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: url)
                guard data.count <= 4 * 1024 * 1024 else {
                    report("Skin-PNG zu groß (max. 4 MiB)")
                    return
                }
                let encoded = data.base64EncodedString() as NSString
                webView?.evaluateJavaScript("window.UViewerNativeSkin.begin(\(jsString(url.lastPathComponent)))") { [weak self] _, error in
                    if let error = error {
                        self?.report("Skin-Importstart fehlgeschlagen: " + error.localizedDescription)
                        return
                    }
                    self?.sendSkinChunk(encoded, offset: 0)
                }
            } catch {
                report("Skin konnte nicht gelesen werden: " + error.localizedDescription)
            }
        }

        private func sendSkinChunk(_ encoded: NSString, offset: Int) {
            guard let webView = webView else { return }
            if offset >= encoded.length {
                webView.evaluateJavaScript("window.UViewerNativeSkin.finish()") { [weak self] _, error in
                    if let error = error { self?.report("Skin-Import fehlgeschlagen: " + error.localizedDescription) }
                }
                return
            }
            let count = min(131072, encoded.length - offset)
            let chunk = encoded.substring(with: NSRange(location: offset, length: count))
            webView.evaluateJavaScript("window.UViewerNativeSkin.append(\(jsString(chunk)))") { [weak self] _, error in
                if let error = error { self?.report("Skin-Übertragung fehlgeschlagen: " + error.localizedDescription) }
                else { self?.sendSkinChunk(encoded, offset: offset + count) }
            }
        }

        private func jsString(_ value: String) -> String {
            let data = try! JSONEncoder().encode(value)
            return String(data: data, encoding: .utf8)!
        }

        private func report(_ message: String) {
            webView?.evaluateJavaScript("window.UViewerNativeImport.error(\(jsString(message)))")
        }

        private func importNextDocument() {
            guard !pendingDocuments.isEmpty else { return }
            let url = pendingDocuments.removeFirst()
            guard url.pathExtension.lowercased() == "cosmetic" else {
                report("Nur .cosmetic-Dateien werden unterstützt: " + url.lastPathComponent)
                importNextDocument()
                return
            }
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: url)
                guard data.count <= 16 * 1024 * 1024 else {
                    report("Cosmetic zu groß (max. 16 MiB): " + url.lastPathComponent)
                    importNextDocument()
                    return
                }
                let base64 = data.base64EncodedString() as NSString
                webView?.evaluateJavaScript("window.UViewerNativeImport.begin(\(jsString(url.lastPathComponent)))") { [weak self] _, error in
                    if let error = error { self?.report("Importstart fehlgeschlagen: " + error.localizedDescription); self?.importNextDocument(); return }
                    self?.sendChunk(base64, offset: 0)
                }
            } catch {
                report("Datei nicht lesbar: " + error.localizedDescription)
                importNextDocument()
            }
        }

        private func sendChunk(_ base64: NSString, offset: Int) {
            guard let webView = webView else { return }
            if offset >= base64.length {
                webView.evaluateJavaScript("window.UViewerNativeImport.finish().finally(() => window.webkit.messageHandlers.nativeImportDone.postMessage('done'))") { [weak self] _, error in
                    if let error = error {
                        self?.report("Import konnte nicht abgeschlossen werden: " + error.localizedDescription)
                        self?.importNextDocument()
                    }
                }
                return
            }
            let count = min(131072, base64.length - offset) // ASCII base64, chunk is divisible by 4
            let chunk = base64.substring(with: NSRange(location: offset, length: count))
            webView.evaluateJavaScript("window.UViewerNativeImport.append(\(jsString(chunk)))") { [weak self] _, error in
                if let error = error {
                    self?.report("Dateiübertragung fehlgeschlagen: " + error.localizedDescription)
                    self?.importNextDocument()
                } else {
                    self?.sendChunk(base64, offset: offset + count)
                }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let scheme = navigationAction.request.url?.scheme,
               !["file", "about", "blob", "data"].contains(scheme) {
                decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }
    }
}
