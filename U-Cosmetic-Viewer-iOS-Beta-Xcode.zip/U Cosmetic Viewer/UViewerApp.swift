import SwiftUI

@main
struct UViewerApp: App {
    var body: some Scene {
        WindowGroup {
            ViewerScreen()
                .preferredColorScheme(.dark)
        }
    }
}

struct ViewerScreen: View {
    var body: some View {
        ViewerWebView()
            .background(Color(red: 0.06, green: 0.075, blue: 0.105))
            .ignoresSafeArea(.keyboard, edges: .bottom)
    }
}
