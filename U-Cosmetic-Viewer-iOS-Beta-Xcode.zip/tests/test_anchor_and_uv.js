const fs=require('fs'),vm=require('vm'),assert=require('assert'),cp=require('child_process');
const src=fs.readFileSync('U Cosmetic Viewer/WebApp/app.js','utf8');
const core=src.slice(src.indexOf('const I='),src.indexOf('const gl='));
const geom=src.slice(src.indexOf('function anchorMatrix('),src.indexOf('function updateCount()'));
const ctx={console,Math,Map,Set,cosmetics:[],only:false,animTime:0};vm.createContext(ctx);
vm.runInContext('const rad=Math.PI/180;'+core+geom,ctx);
function load(filename){let text=cp.execFileSync('python',['-c',`import json,zipfile;z=zipfile.ZipFile(${JSON.stringify('U Cosmetic Viewer/WebApp/examples/'+filename)});print(json.dumps({'meta':json.loads(z.read('cosmetic.json')),'parts':json.loads(z.read('model.json'))['parts'],'anim':json.loads(z.read('animations.json'))}))`]);return JSON.parse(text)}
const head=load('Graffiti-Kopfband-A.cosmetic'),wings=load('StreetTag-Wings-V6.cosmetic');
ctx.head=head;ctx.wings=wings;
let report=vm.runInContext(`(()=>{
const make=data=>{const c={meta:data.meta,parts:data.parts,partById:new Map(data.parts.map(p=>[p.id,p])),textures:{},channels:{}};for(let tr of data.anim.tracks)(c.channels[tr.target]??=[]).push({...tr,duration:data.anim.durationSeconds});return c};
const h=make(head),w=make(wings),root=scale(1,-1,-1),headCommands=cosmeticCommands(h,root,0),wingCommands=cosmeticCommands(w,root,0);
const band=headCommands.find(c=>c.ext[3]>0.6&&c.ext[4]>.1&&c.ext[5]<.02);
const all=wingCommands.flatMap(c=>c.corners);
return {headAnchor:transformPoint(anchorMatrix(root,'head'),0,0,0),bodyAnchor:transformPoint(anchorMatrix(root,'body'),0,0,0),bandMinY:Math.min(...band.corners.map(p=>p[1])),bandMaxY:Math.max(...band.corners.map(p=>p[1])),wingLeft:Math.min(...all.map(p=>p[0])),wingRight:Math.max(...all.map(p=>p[0])),wingDepthMax:Math.max(...all.map(p=>p[2])),wingUv:wingCommands.find(c=>c.texture===null)?.uv || wingCommands[0].uv,commands:headCommands.length+wingCommands.length}
})()`,ctx);
console.log(report);
assert(Math.abs(report.headAnchor[1]-.5)<1e-8,'head pivot must be at neck (Y=0.5), not top of head');
assert(Math.abs(report.bodyAnchor[1]-.5)<1e-8,'body pivot must also be at neck');
assert(report.bandMinY>.6&&report.bandMaxY<1,'headband must sit on the head, not above it');
assert(report.wingLeft<-1.4&&report.wingRight>1.4,'both wing sides present');
assert(report.wingDepthMax<0,'wing tips remain behind player-facing plane');
assert(!src.includes("meta.id==='streettag_wings_v6'?'texture'"),'no hardcoded flip of one imported package');
assert(!src.includes('flipV:c.orientationMode'),'no hidden vertical texture mirror');
console.log('Head anchor, wing symmetry and authored UV conventions passed');
