const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('U Cosmetic Viewer/WebApp/app.js','utf8');
const core=src.slice(src.indexOf('const I='),src.indexOf('const gl='));
const draw=src.slice(src.indexOf('function drawBox('),src.indexOf('function persp('));
const buffers=[];
const gl={ARRAY_BUFFER:34962,DYNAMIC_DRAW:35048,FLOAT:5126,TRIANGLES:4,
 uniformMatrix4fv(){},uniform4fv(){},bindTexture(){},bindBuffer(){},enableVertexAttribArray(){},vertexAttribPointer(){},drawArrays(){},
 bufferData(_target,values){buffers.push([...values])}};
const ctx={Math,gl,viewProj:[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],matrixLoc:0,tintLoc:0,vb:0,tb:1,posLoc:0,uvLoc:1,white:1};
vm.createContext(ctx);
vm.runInContext(core+src.slice(src.indexOf('const faceIndices='),src.indexOf('function drawBox('))+draw,ctx);
buffers.length=0;
vm.runInContext('drawBox(I(),[0,0,0,1,1,0],1,Array(6).fill([0.25,0.5,0.5,0.75]))',ctx);
const uv=buffers[1];
assert.deepStrictEqual(uv.slice(0,4),[.25,.5,.5,.5]);
assert.strictEqual(uv[5],.75);
assert(!src.includes("meta.id==='streettag_wings_v6'?'texture'"));
assert(src.includes('const t=texFromImage(im,true)'));
console.log('Author-defined UV, spritesheet orientation and flat-plane mapping passed');
