# Beta 0.11 – Abgleich

- Verwendete Referenz: `U-Cosmetic-Mod-v0.4.3-beta(1).jar` (Fabric Java 25).
- Java-Bytecode untersucht: `CosmeticDefinition.pose`, `AnimationMath.loop`, `CosmeticRenderLayer.geometry`, `anchor`.
- V6-Flügel und Kopfband im Viewer sind SHA-256-identisch zu den JAR-internen Dateien.
- Korrigiert: additive Tracks, step-Keyframe-Grenzen, kombinierte uniforme/achsenbezogene Skalierung.
- Bestehende Tests für Modellhierarchie, Kopfanker und Flügelsymmetrie erneut ausführen.
- Kein vollständiger visueller Browser-/iPhone-Grafiktest möglich; keine Zusage für 1:1-Pixelgleichheit.
