# U Cosmetic 3D Viewer Beta 0.8 – Testbericht

- JavaScript-Syntax: `node --check` bestanden.
- Formatversionen 1 und 2: vier Original-Beispieldateien im Browser mit simuliertem WebGL-Kontext importiert.
- ZIP-Fehler und doppelte Cosmetic-ID: Ablehnung bzw. Ersetzen erfolgreich geprüft.
- Modellhierarchie: auch bei umgekehrter Reihenfolge gleiche Ergebnisse.
- Flügel-Geometrie: links/rechts symmetrisch, hinter dem Spieler, 16 sichtbare Haupt-Layer zum Zeitpunkt 0.
- Spritesheet: 16 Frames in 4×4, Seitenverhältnis der originalen V6-Textur geprüft.
- Kamera: berechnet Entfernung aus tatsächlichen Modellgrenzen und Canvas-Seitenverhältnis.
- Referenzbild `tests/reference_wings.png`: softwarebasierte Projektion der originalen V6-Texturen, keine WebGL-Darstellung.

**Nicht geprüft:** echte WebGL-Pixel-Ausgabe und Aussehen auf dem iPhone, Xcode-Build und ESign-Installation. Dafür muss die neue IPA auf dem Gerät getestet werden.
