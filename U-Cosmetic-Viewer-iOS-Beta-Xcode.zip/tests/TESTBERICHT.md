# U Cosmetic Viewer Beta 0.10 – Prüfbericht

## Bestanden

- `node --check` für die komplette JavaScript-Anwendung.
- Browser-Importtest mit simuliertem WebGL: alle vier originalen `.cosmetic`-Pakete werden geladen, Texturen dekodiert, Pakete erneut importiert ohne Duplikate, ungültige ZIP-Dateien abgewiesen.
- PNG-Skin-Import: echtes PNG-Dekodieren im Testbrowser, Skin-Dimensionen und UI-Status geprüft.
- Kopfanker: Head- und Body-Pivot jeweils Y=0,5 Welt-Einheiten (8 Modellpixel unter der Kopfoberkante). Das Graffiti-Kopfband liegt zwischen Y=0,75 und Y=0,9375 statt oberhalb des Kopfes.
- Flügel: Symmetrie links/rechts, Z-Position hinter dem Spieler, Modellhierarchie unabhängig von der Reihenfolge der Teile.
- Textur-UVs: Originalzuordnung innerhalb der Spritesheet-Frames, keine versteckte vertikale Spiegelung. 16 Frames im 4×4-Raster der V6-Textur geprüft.
- Skin-Kopf-UVs für obere/untere Flächen; Kameradistanz und dynamische Zoomgrenzen.

## Nicht geprüft

- Echter WebGL-Grafik-Render: Die Browserumgebung stellt keinen WebGL-Kontext bereit. Der Browser-Importtest verwendet deshalb einen Mock für die GPU-Aufrufe, aber echte PNG-Dekodierung.
- Echte iPhone-Grafikdarstellung und IPA-Installation.
- Pixelgenauer Vergleich mit dem **aktuellen** Minecraft-Mod-Renderer: Es liegt nur das alte Mod-Quellcodearchiv v0.2 vor, das noch keinen fertigen Minecraft-Render-Layer enthält.

Die korrigierte Version ist eine testbare Beta, keine Zusicherung einer 1:1-Übereinstimmung.
