// Structural parity checks with Minecraft PlayerModel (right arm/leg are -X)
// and render layer's opaque/transparent passes.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('U Cosmetic Viewer/WebApp/app.js','utf8');
const core=src.slice(src.indexOf('const I='),src.indexOf('const gl='));
const skin=src.slice(src.indexOf('const skinParts='),src.indexOf('let fallbackSkinCanvas='));
const anchors=src.slice(src.indexOf('function anchorMatrix('),src.indexOf('function keyValue('));
const ctx={Math};vm.createContext(ctx);vm.runInContext(core+skin+anchors,ctx);
const positions=vm.runInContext(`Object.fromEntries(skinParts.map(p=>[p.name,p.pos]))`,ctx);
assert(positions.rightArm[0]<0 && positions.leftArm[0]>0,'Arms swapped');
assert(positions.rightLeg[0]<0 && positions.leftLeg[0]>=0,'Legs swapped');
const a=vm.runInContext(`({right:anchorMatrix(scale(1,-1,-1),'right_arm')[12],left:anchorMatrix(scale(1,-1,-1),'left_arm')[12]})`,ctx);
assert(a.right<0 && a.left>0,'Arm anchors swapped');
assert(src.includes('const t=texFromImage(im,false)'),'Cosmetic texture upload must preserve PNG row order');
assert(src.includes('gl.disable(gl.BLEND)') && src.includes('gl.depthMask(false)'),'Two-pass transparency required');
assert(src.includes('alphaPass==1.0') && src.includes('alphaPass==2.0'),'Opaque and translucent fragments need separate passes');
console.log('Minecraft limb coordinates, attachment pivots, PNG orientation and alpha passes OK');
