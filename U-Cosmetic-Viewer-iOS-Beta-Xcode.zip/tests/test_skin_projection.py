"""Regression: Minecraft pixel offsets must be divided by 16 before world transforms."""
from pathlib import Path
import re, math
src=(Path(__file__).resolve().parents[1]/'U Cosmetic Viewer/WebApp/app.js').read_text()
assert 'move(0,offsetY/16,0)' in src, 'skin origin must use Minecraft pixel scale'
assert 'move(0,offsetY,0)' not in src
# Model top and bottom in world units, after converting pixel coordinate system.
# head: y=0..8, legs: y=20..32, torso anchor offset=-12 pixels.
ys=[-(y-12)/16 for y in (0,8,20,32)]
assert max(ys)-min(ys)==2.0
assert -2 < min(ys) < 0 < max(ys) < 2
print('Skin transform regression passed; full 2-block model centered near camera')
