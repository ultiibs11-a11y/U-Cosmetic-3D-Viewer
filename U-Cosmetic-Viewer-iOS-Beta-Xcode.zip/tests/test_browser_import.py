from playwright.sync_api import sync_playwright
from pathlib import Path
import base64
base=Path(__file__).resolve().parents[1]/'U Cosmetic Viewer/WebApp'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':420,'height':900})
 page.on('pageerror',lambda e:print('PAGE ERROR',e))
 html=(base/'index.html').read_text().replace('<link rel="stylesheet" href="style.css">','<style>'+(base/'style.css').read_text()+'</style>').replace('<script src="vendor/jszip.min.js"></script>','').replace('<script src="app.js"></script>','')
 page.set_content(html)
 page.evaluate('''()=>{
 const orig=HTMLCanvasElement.prototype.getContext;
 const fake=new Proxy({getShaderParameter:()=>true,getAttribLocation:()=>0,getUniformLocation:()=>({}),createShader:()=>({}),createProgram:()=>({}),createTexture:()=>({}),createBuffer:()=>({})},{get:(obj,key)=>key in obj?obj[key]:()=>{}});
 HTMLCanvasElement.prototype.getContext=function(type,...args){return type==='webgl'?fake:orig.call(this,type,...args)};
 }''')
 page.add_script_tag(content=(base/'vendor/jszip.min.js').read_text())
 page.add_script_tag(content=(base/'app.js').read_text())
 for filename in ['StreetTag-Wings-V6.cosmetic','Graffiti-Kopfband-A.cosmetic','orbit-test.cosmetic','streettag-test.cosmetic']:
  encoded=base64.b64encode((base/'examples'/filename).read_bytes()).decode()
  page.evaluate('async b=>{let raw=atob(b),u=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)u[i]=raw.charCodeAt(i);await loadCosmetic(u.buffer,"test.cosmetic")}',encoded)
  print('loaded',filename,page.locator('#status').inner_text())
 assert page.locator('#count').inner_text()=='4 aktiv'
 page.wait_for_timeout(200)
 # Reimporting the same package must replace, not duplicate, a cosmetic.
 encoded=base64.b64encode((base/'examples/StreetTag-Wings-V6.cosmetic').read_bytes()).decode()
 page.evaluate('async b=>{let raw=atob(b),u=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)u[i]=raw.charCodeAt(i);await loadCosmetic(u.buffer,"again.cosmetic")}',encoded)
 assert page.locator('#count').inner_text()=='4 aktiv'
 assert page.evaluate('cosmetics.length')==4
 # Invalid archives must fail without mutating the library.
 try:
  page.evaluate('async ()=>{await loadCosmetic(new Uint8Array([1,2,3]).buffer,"bad.cosmetic")}')
  raise AssertionError('Invalid archive accepted')
 except Exception:pass
 assert page.evaluate('cosmetics.length')==4

 assert page.evaluate("cosmetics.every(c=>c.parts.length>0)&&!!cosmetics[0].textures['textures/part_0.png']")
 assert page.evaluate('Number.isFinite(distance)&&distance>5')
 print('Camera distance',page.evaluate('distance'))
 page.screenshot(path=str(base.parent.parent/'tests/layout_test.png'),full_page=True)
 b.close()
