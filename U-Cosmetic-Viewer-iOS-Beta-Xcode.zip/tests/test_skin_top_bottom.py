"""Regression for head top/bottom on the Y-flipped Minecraft player model."""
from pathlib import Path
s = (Path(__file__).resolve().parents[1] / 'U Cosmetic Viewer/WebApp/app.js').read_text()
assert 'if(!only)drawPlayer(scale(1,-1,1));' in s
assert 'r(u+d+w,v,w,d),       // local +Y => physical bottom' in s
assert 'r(u+d,v,w,d)          // local -Y => physical top' in s
assert 'skinUV(p.outer' in s
# Vanilla head atlas: top is (8,0)-(16,8), bottom is (16,0)-(24,8).
u,v,w,h,d = 0,0,8,8,8
rects = [(u+d+w,v,w,d), (u+d,v,w,d)]
assert rects[0] == (16,0,8,8)
assert rects[1] == (8,0,8,8)
print('Head top/bottom atlas regression passed')
