# Beta 0.12 – Fehleranalyse

Referenz: `U-Cosmetic-Mod-v0.4.3-beta(1).jar`, insbesondere `CosmeticRenderLayer.geometry`, `CosmeticDefinition.pose`, `CosmeticRenderLayer.anchor`.

1. **Cosmetic-UV**: PNG wird jetzt ohne Y-Spiegelung in WebGL geladen; `uv` referenziert dieselbe obere Bildzeile wie die Fabric-Mod. Vorher: `texFromImage(im,true)`.
2. **Skin-Links/Rechts**: Die rechte Minecraft-Gliedmaße liegt auf der negativen X-Seite. Vorher war sie in `skinParts` auf der positiven Seite.
3. **ModelPart-Anker**: Arm-Pivot aus PlayerModel-Standardpose: x=±5, y=2 Pixel unter Hals. Beine x=±1.9, y=12 Pixel unter Hals. Statische Pose ohne laufende Animation.
4. **Alpha-Komposition**: Der bisherige einzelne transparente Pass hatte kein Tiefenschreiben für opake Pixel; dadurch konnten Rückseiten über Vorderseiten erscheinen. Jetzt zwei Pässe.

Grenzen: Browser-Rendering ist durch WebGL-Blockade in dieser Umgebung nicht visuell verifizierbar; auf iPhone muss weiterhin geprüft werden. Die WebGL-Implementierung ist kein eingebetteter Minecraft-Renderer.
