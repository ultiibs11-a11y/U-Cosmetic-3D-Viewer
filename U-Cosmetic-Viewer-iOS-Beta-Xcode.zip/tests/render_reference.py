import zipfile,json,io,math
import numpy as np, cv2
from PIL import Image
from pathlib import Path
base=Path(__file__).resolve().parents[1]
p=base/'U Cosmetic Viewer/WebApp/examples/StreetTag-Wings-V6.cosmetic'
with zipfile.ZipFile(p) as z:
 parts=json.loads(z.read('model.json'))['parts'];textures={n:Image.open(io.BytesIO(z.read(n))).convert('RGBA') for n in z.namelist() if n.startswith('textures/')}
byid={part['id']:part for part in parts}

def tr(x,y,z):
 m=np.eye(4);m[:3,3]=[x,y,z];return m

def ry(d):
 a=math.radians(d);m=np.eye(4);m[0,0]=m[2,2]=math.cos(a);m[0,2]=math.sin(a);m[2,0]=-math.sin(a);return m
root=np.diag([1,-1,-1,1]);anchor=tr(0,-.5,0);cache={}
def model(part):
 if part['id'] in cache:return cache[part['id']]
 parent=model(byid[part['parent']]) if 'parent' in part else root@anchor
 m=parent@tr(*(np.array(part['position'])/16))@ry(part['rotation'][1]);cache[part['id']]=m;return m
w,h=850,850
img=np.zeros((h,w,4),np.uint8)
# rotate to 3/4 angle, with camera center y=.15 and distance 10.5
view=tr(0,0,-10.5)@ry(-24)@tr(0,-.15,0)
fx=850
cmds=[]
for part in parts:
 if not part.get('texture') or not part['size'][0] or not part['size'][1]:continue
 m=view@model(part)
 x,y,z=np.array(part['offset'])/16;dx,dy,_=np.array(part['size'])/16
 coords=[(x,y,z),(x+dx,y,z),(x+dx,y+dy,z),(x,y+dy,z)]
 pts=[];depth=[]
 for pt in coords:
  v=m@np.array([*pt,1]);zz=-v[2];pts.append([w/2+fx*v[0]/zz,h/2-fx*v[1]/zz]);depth.append(zz)
 cmds.append((np.mean(depth),np.float32(pts),part))
for _,pts,part in sorted(cmds,reverse=True):
 tex=textures[part['texture']];frames=part.get('textureFrames',1);cols=part.get('textureColumns',1);rows=math.ceil(frames/cols)
 im=np.array(tex.crop((0,0,tex.width//cols,tex.height//rows)))
 col=part.get('color','ffffff');tint=np.array([int(col[i:i+2],16)/255 for i in (0,2,4)]);im[:,:,:3]=(im[:,:,:3]*tint).astype('uint8')
 src=np.float32([[0,0],[im.shape[1],0],[im.shape[1],im.shape[0]],[0,im.shape[0]]]);matrix=cv2.getPerspectiveTransform(src,pts)
 warped=cv2.warpPerspective(im,matrix,(w,h),flags=cv2.INTER_LINEAR)
 a=warped[:,:,3:4].astype(np.float32)/255
 img[:,:,:3]=(warped[:,:,:3]*a+img[:,:,:3]*(1-a)).astype(np.uint8)
 img[:,:,3]=255
Image.fromarray(img,'RGBA').convert('RGB').save(base/'tests/reference_wings.png')
print('reference_wings.png generated, textured parts',len(cmds))
