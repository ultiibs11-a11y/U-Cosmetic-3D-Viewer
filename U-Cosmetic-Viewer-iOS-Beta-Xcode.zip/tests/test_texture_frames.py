import zipfile,io,json
from PIL import Image
from pathlib import Path
base=Path(__file__).resolve().parents[1]/'U Cosmetic Viewer/WebApp/examples'
with zipfile.ZipFile(base/'StreetTag-Wings-V6.cosmetic') as z:
 parts=json.loads(z.read('model.json'))['parts']
 frames=[p for p in parts if p.get('textureFrames',1)>1]
 assert len(frames)==16
 for path in set(p['texture'] for p in frames):
  im=Image.open(io.BytesIO(z.read(path)))
  p=next(p for p in frames if p['texture']==path)
  n=p['textureFrames'];cols=p['textureColumns'];rows=(n+cols-1)//cols
  assert im.width%cols==0 and im.height%rows==0
  tile=im.crop((0,0,im.width//cols,im.height//rows))
  assert tile.getbbox() and tile.width/tile.height==384/448
print('Sprite sheets: 16-frame wings, 4×4 grid, valid aspect and alpha')
