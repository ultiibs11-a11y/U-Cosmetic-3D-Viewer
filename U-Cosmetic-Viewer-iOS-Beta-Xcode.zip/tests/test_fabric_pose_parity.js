// Regression tests against CosmeticDefinition.pose and AnimationMath.loop in
// U Cosmetic Mod v0.4.3 (classfile decompiled with javap).
const assert=require('assert'),fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('U Cosmetic Viewer/WebApp/app.js','utf8');
const core=src.slice(src.indexOf('const I='),src.indexOf('const gl='));
const geom=src.slice(src.indexOf('function anchorMatrix('),src.indexOf('function updateCount()'));
const ctx={Math,Map,Set,cosmetics:[],only:false,animTime:0};vm.createContext(ctx);
vm.runInContext('const rad=Math.PI/180;'+core+geom,ctx);
ctx.fixture={meta:{attachTo:'body'},parts:[{id:'pivot',position:[0,0,0],rotation:[0,0,0],size:[0,0,0],offset:[0,0,0],stretch:[1,1,1]},{id:'plane',parent:'pivot',position:[2,4,3],rotation:[0,0,0],size:[4,8,0],offset:[-2,-4,0],stretch:[1,1,1]}]};
const result=vm.runInContext(`(()=>{
 const c={...fixture,partById:new Map(fixture.parts.map(p=>[p.id,p])),channels:{plane:[
  {property:'scale',duration:2,interpolation:'step',keys:[[0,0],[1,0.5]]},
  {property:'scaleX',duration:2,interpolation:'step',keys:[[0,0],[1,-0.5]]},
  {property:'scaleX',duration:2,interpolation:'step',keys:[[0,0],[1,0.25]]}
 ]},textures:{}};
 return [cosmeticCommands(c,scale(1,-1,-1),0)[0],cosmeticCommands(c,scale(1,-1,-1),1)[0]];
})()`,ctx);
// Java's animation keyframes are step: the NEXT value takes effect at t=1 exactly.
assert(Math.abs(result[0].ext[3]-.25)<1e-8);
assert(Math.abs(result[1].ext[3]-.375)<1e-8); // size multiplied by 1.5
// Java multiplies stretch by uniform 1.5 AND scaleX by (1-0.5+0.25)=0.75
const xSpan=r=>Math.max(...r.corners.map(p=>p[0]))-Math.min(...r.corners.map(p=>p[0]));
assert(Math.abs(xSpan(result[0])-.25)<1e-8);
assert(Math.abs(xSpan(result[1])-(.25*1.5*1.5*.75))<1e-8);
console.log('Fabric pose parity: duplicate tracks, step boundary, uniform/axis scale OK');
