from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'U Cosmetic Viewer/WebApp/app.js').read_text()
assert 'renderCosmetics(scale(1,-1,-1))' in s
assert 'head:[0,-16,0]' in s
assert 'body:[0,-8,0]' in s
assert 'gl.depthMask(false)' in s
assert 'cosmeticCommands(c,root,cameraBoundsTime)' in s
assert 'autoFitCamera()' in s
print('Anchor, transparency and camera regression checks passed')
