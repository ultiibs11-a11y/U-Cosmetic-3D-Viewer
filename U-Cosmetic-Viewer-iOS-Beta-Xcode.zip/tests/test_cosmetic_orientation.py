"""Coordinate regression: match Minecraft's neck pivot and authored UV convention."""
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'U Cosmetic Viewer/WebApp/app.js').read_text()
assert 'renderCosmetics(scale(1,-1,-1))' in s
assert 'head:[0,-8,0],body:[0,-8,0]' in s
assert 'gl.depthMask(false)' in s
assert 'for(const t of sample)for(const cmd of cosmeticCommands(c,root,t))' in s
assert 'autoFitCamera()' in s
assert 'orientationMode' not in s
print('Head/body pivot, alpha and animation-aware camera checks passed')
