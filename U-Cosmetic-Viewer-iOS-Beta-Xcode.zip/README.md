# U Cosmetic 3D Viewer – iOS Beta

Native iPhone/iPad shell in SwiftUI + WKWebView with bundled offline WebGL viewer.

## Unsigned `.ipa` for ESign – macOS / GitHub Actions

An IPA must contain a compiled ARM64 iOS executable; changing `.zip` to `.ipa` does **not** work.

**GitHub Actions method:** upload **the contents of this folder** to a new GitHub repository, enable Actions, open **Actions → Build unsigned iOS IPA (ESign) → Run workflow**. Download artifact `U-Cosmetic-Viewer-Beta-unsigned-IPA`, unzip the GitHub artifact and find `U-Cosmetic-Viewer-Beta-unsigned.ipa`. Import into ESign; signing requires your own valid signing certificate and provisioning profile. Validity is controlled by Apple, not by this project. An unsigned IPA cannot install directly.

**Local Mac method:** `brew install xcodegen`; `xcodegen generate`; open `UCosmeticViewer.xcodeproj` in Xcode to test on iPhone using your Apple account, or build with the `xcodebuild` command in `.github/workflows/build-ipa.yml` and zip `Payload/UCosmeticViewer.app` for ESign.

## Included functions

Minecraft PNG skin picker (standard/slim); multiple `.cosmetic` packages, full 3D viewer with WebGL/drag/pinch; animations pause, speed, timeline; sample wings and headband; PNG screenshot via native iOS sharing sheet. App works locally, without a network connection or login. It does not import arbitrary code.

## Scope and validation

This is an **iOS project, not a prebuilt IPA**. This environment is Linux and cannot compile the final iOS executable. The workflow must be run on macOS; a real device test is still needed. The HTML/WebGL viewer is beta and differs in some UV/animation details from Minecraft. Imported files are not persistent across app relaunch. Cosmetic packages are decoded locally on the device.

## Beta 0.2 – iOS Cosmetic-Dateiauswahl

Der Cosmetic-Import nutzt nun den nativen iOS-Dateiauswahldialog. Dateien mit der eigenen Endung `.cosmetic` sind dadurch auswählbar. Es können mehrere Dateien markiert werden. Andere Endungen werden zurückgewiesen; das ZIP-basierte Cosmetic-Format wird im Viewer geprüft.

**Wichtig:** Nach dem Austausch des Projekt-ZIPs muss GitHub Actions die IPA neu bauen. Die alte installierte IPA enthält diese Korrektur nicht.

## Beta 0.3 – Skin-Fix (iPhone)

Der Skin-Import verwendet nun ebenfalls einen nativen iOS-Dokumentenpicker (PNG). Nach der Auswahl wird der Skin mit Dateiname und Miniaturansicht bestätigt und die 3D-Spieleransicht aktiviert. Die Skin-Atlas-Koordinaten wurden korrigiert (insbesondere Kopf und linke Gliedmaßen). Unterstützt werden 64×64, 64×32 und HD-Vielfache davon. Eine tatsächliche iPhone-Grafikprüfung ist noch erforderlich.
