# U Cosmetic 3D Viewer – iOS Beta

Native iPhone/iPad shell in SwiftUI + WKWebView with bundled offline WebGL viewer.

## Unsigned `.ipa` for ESign – macOS / GitHub Actions

An IPA must contain a compiled ARM64 iOS executable; changing `.zip` to `.ipa` does **not** work.

**GitHub Actions method:** upload **the contents of this folder** to a new GitHub repository, enable Actions, open **Actions → Build unsigned iOS IPA (ESign) → Run workflow**. Download artifact `U-Cosmetic-Viewer-Beta-unsigned-IPA`, unzip the GitHub artifact and find `U-Cosmetic-Viewer-Beta-unsigned.ipa`. Import into ESign; signing requires your own valid signing certificate and provisioning profile. Validity is controlled by Apple, not by this project. An unsigned IPA cannot install directly.

**Local Mac method:** `brew install xcodegen`; `xcodegen generate`; open `UCosmeticViewer.xcodeproj` in Xcode to test on iPhone using your Apple account, or build with the `xcodebuild` command in `.github/workflows/build-ipa.yml` and zip `Payload/UCosmeticViewer.app` for ESign.

## Included functions

Minecraft PNG skin picker (standard/slim); multiple `.cosmetic` packages, full 3D viewer with WebGL/drag/pinch; animations pause, speed, timeline; sample wings and headband; PNG screenshot via native iOS sharing sheet. App works locally, without a network connection or login. It does not import arbitrary code.

## Scope and validation

This is an **iOS project, not a prebuilt IPA**. This environment is Linux and cannot compile the final iOS executable. The workflow must be run on macOS; a real device test is still needed. The HTML/WebGL viewer is beta and differs in some UV/animation details from Minecraft. Imported files are not persistent across app relaunch. Cosmetic packages are decoded locally on the device.

## Beta 0.2 – iOS Cosmetic-Dateiauswahl

Der Cosmetic-Import nutzt nun den nativen iOS-Dateiauswahldialog. Dateien mit der eigenen Endung `.cosmetic` sind dadurch auswählbar. Es können mehrere Dateien markiert werden. Andere Endungen werden zurückgewiesen; das ZIP-basierte Cosmetic-Format wird im Viewer geprüft.

**Wichtig:** Nach dem Austausch des Projekt-ZIPs muss GitHub Actions die IPA neu bauen. Die alte installierte IPA enthält diese Korrektur nicht.

## Beta 0.3 – Skin-Fix (iPhone)

Der Skin-Import verwendet nun ebenfalls einen nativen iOS-Dokumentenpicker (PNG). Nach der Auswahl wird der Skin mit Dateiname und Miniaturansicht bestätigt und die 3D-Spieleransicht aktiviert. Die Skin-Atlas-Koordinaten wurden korrigiert (insbesondere Kopf und linke Gliedmaßen). Unterstützt werden 64×64, 64×32 und HD-Vielfache davon. Eine tatsächliche iPhone-Grafikprüfung ist noch erforderlich.

## Beta 0.4 – 3D-Skin sichtbar (Kamera-/Koordinaten-Fix)

Der Skin-Renderer hat den vertikalen Versatz von 12 Modellpixeln fälschlich als 12 ganze WebGL-Einheiten verwendet. Dadurch wurde der Spieler außerhalb des Kamerabilds gezeichnet. Der Versatz wird nun korrekt durch 16 geteilt. Dies behebt die Ursache der leeren 3D-Spielervorschau, während die importierte PNG-Miniatur bereits angezeigt wurde. Die Vorschau sollte nun den vollständigen Minecraft-Spieler zeigen. Eine Prüfung auf einem echten iPhone steht noch aus.

## Beta 0.5 – Skin-Atlas und vollständiger Spieler

Die bisherigen Screenshots zeigten korrekt importierte PNG-Dateien, aber einen fragmentierten 3D-Spieler (blaue Kopfpartien, transparente/fehlende Körperteile). Ursache war eine vertikal invertierte WebGL-Textur: Die Skin-UVs verwenden PNG-Koordinaten von oben links, während die Textur beim Hochladen zusätzlich gespiegelt wurde. **Skin-Texturen** werden nun ohne vertikale Spiegelung geladen; die bisherige Texturorientierung für Cosmetics bleibt unverändert.

Zusätzlich korrigiert: Zuordnung der sechs Körperteile (Kopf, Rumpf, linker/rechter Arm, linkes/rechtes Bein), Skin-Atlas-Flächen, Kopf-/Kleidungs-Overlay als transparente zweite Schicht, Legacy-Skin-Spiegelung der linken Gliedmaßen und Zentrierung der 2 Block hohen Figur. Die native iOS-Dateiauswahl und das App-Icon bleiben erhalten.

**Tests:** JavaScript-Syntax und statische Skin-Atlas-/Koordinatenprüfungen bestanden. In dieser Linux-Umgebung konnte der Browser keinen WebGL-Grafikkontext bereitstellen; ein echter visueller iPhone-Test und der Xcode-Build auf GitHub Actions stehen weiterhin aus. Bitte die neue IPA auf dem Gerät prüfen.

## Beta 0.6 – Kopf-Oberseite und Unterseite

Die Skin-UVs für die beiden horizontalen Flächen wurden passend zur invertierten Y-Achse vertauscht. Die Änderung gilt für alle Körperteile einschließlich Kopf und transparenter zweiter Schicht. Cosmetic-Dateien und Import bleiben unverändert.

## Beta 0.7 – Cosmetic orientation and anchors
The WebGL viewer now maps Minecraft cosmetic +Z (behind player) to WebGL -Z and anchors parts at their corresponding body-part pivots. Loading back cosmetics also widens the camera so both wings fit. The skin atlas and iOS file picker remain unchanged.


## Beta 0.8 – Import- und Modellrenderer-Überarbeitung

- **Vollständige Modellhierarchie:** Eltern-Transformationen werden unabhängig von der Reihenfolge der Modellteile berechnet; Anker sind in Minecraft-Modellpixeln definiert.
- **3D-Flächen:** Nulltiefe Flügel-Layer werden nicht mehr doppelt gerendert. Transparente Flächen werden relativ zur Kamera nach Tiefe sortiert und ohne Depth-Write überlagert. Der Spieler bleibt im Tiefenpuffer und verdeckt die Flügel korrekt.
- **Materialien:** Teile ohne PNG verwenden jetzt tatsächlich Weiß als Basismaterial, damit die Farbwerte im Kopfband funktionieren.
- **Kamera:** Beim Import, Umschalten, Löschen und Zurücksetzen wird die Kamera auf die tatsächlichen 3D-Grenzen der geladenen Modelle eingestellt – auch im iPhone-Hochformat.
- **Animation:** Standardinterpolation `smooth`, Paketdauer je Cosmetic, Spritesheet-Frames und mehrere Cosmetics gleichzeitig.
- **Import:** Validierung von ZIP-Pfaden, Paketgrößen, IDs, Modellhierarchien, Texturverweisen und Keyframes; erneuter Import derselben ID ersetzt das vorhandene Cosmetic statt es doppelt zu rendern.
- **Kompatibilität:** Formatversion 1 und 2, V6-Flügel und Kopfband als Testpakete. Skin-Importer und iOS-Dateiauswahl bleiben erhalten.

### Teststand

JavaScript-Syntax und automatische Tests für vier echte Cosmetic-Dateien, ungültige ZIP-Dateien, doppelte Imports, Modell-Symmetrie, Hierarchien und Sprite-Frames wurden ausgeführt. Ein CPU-basiertes 2D-Referenzbild der Flügel ist unter `tests/reference_wings.png` enthalten; dies ist **kein** Nachweis einer erfolgreichen WebGL-/iPhone-Darstellung. Eine echte IPA kann erst durch den macOS-GitHub-Workflow kompiliert werden. Bitte die 3D-Ansicht auf deinem iPhone testen.

### Aktualisierung auf GitHub (iPhone)

Die Datei `U-Cosmetic-Viewer-iOS-Beta-Xcode.zip` im Repository durch die neue gleichnamige ZIP ersetzen. Der bereits vorhandene GitHub-Workflow entpackt diese Datei und baut die unsignierte IPA. Nach dem erfolgreichen Build die IPA in ESign signieren und installieren.

## Beta 0.9 – Flügel oben/unten korrigieren

Für die mitgelieferten **StreetTag Wings V6** ist die vertikale Texturzuordnung innerhalb des jeweils aktiven Animationsframes standardmäßig umgekehrt. Der Skin und alle anderen Cosmetics behalten ihre bisherigen Koordinaten.

In der Cosmetic-Liste erscheint für BACK-Cosmetics ein Auswahlfeld **Flügel-Ausrichtung** mit drei Varianten: **Textur oben/unten tauschen** (Standard für V6), **Original** (bisherige Darstellung) und **Ganzes Modell umdrehen** (falls nicht die Bildtextur, sondern die gesamte Geometrie invertiert ist). Die Auswahl wirkt unmittelbar, ohne Neuimport oder Neubau der IPA. Beim erneuten Import derselben Cosmetic-ID bleibt die gewählte Orientierung innerhalb der Sitzung erhalten.

Tests: UV-Koordinaten bleiben beim vertikalen Tausch im gewählten Spritesheet-Frame; vorhandene Import-, Geometrie-, Skin- und Animationstests. Kein vollständiger iPhone-Grafiktest verfügbar.

## Beta 0.10 – Import-/Koordinaten-Audit

- **Kopfanker korrigiert:** Der Kopf und der Oberkörper teilen sich den Hals-Pivot (8 Modellpixel unterhalb der Kopfoberkante). Der alte Kopfanker war 8 Pixel zu hoch; das betraf jedes HEAD-Cosmetic.
- **Dateien sind maßgeblich:** Keine versteckte, auf V6-ID beschränkte Spiegelung mehr. Die Flügel-UVs verwenden die ursprünglichen Bildkoordinaten je Animationsframe. Der experimentelle Ausrichtungs-Schalter aus Beta 0.9 wurde entfernt, weil er keine belastbare Lösung für das Format war.
- **Kamera bei Animationen:** Die automatische Kameradistanz berücksichtigt nun auch Keyframe-Positionen und nicht nur den Anfangsframe; Zoomgrenzen skalieren mit dem tatsächlichen Modell.
- **Performance:** Der Fallback-Skin wird nur einmal erzeugt.
- **Tests:** Vier echte Cosmetic-Pakete importiert; Head-Pivot und tatsächliche Höhen des Kopfbands geprüft; Flügelsymmetrie und Rückenlage, UVs, 16-Frame-Spritesheet, Animations-Kameragrenzen, erneuter Import und kaputte Archive geprüft.

**Noch nicht garantiert:** pixelgenaue Übereinstimmung mit der aktuell installierten Minecraft-Mod. Der hier vorhandene ältere Mod-Quellcode (v0.2) enthält noch nicht den aktuellen Minecraft-Renderer. Für einen 1:1-Abgleich benötigen wir den Quellcode der neuesten Mod-JAR bzw. den Render-Layer. Auf dieser Linux-Umgebung ist außerdem kein echter iPhone-Grafiktest oder Xcode-Build möglich.

## Beta 0.11 – Abgleich mit der tatsächlichen Minecraft-Mod-JAR

Die Original-JAR `U-Cosmetic-Mod-v0.4.3-beta` wurde analysiert (insbesondere
`CosmeticDefinition.pose`, `AnimationMath.loop` und `CosmeticRenderLayer`).
Die im Paket enthaltenen Original-Cosmetics wurden per SHA-256 mit den
beiden Beispiel-Cosmetics im Viewer verglichen: beide stimmen bytegenau überein.

Korrigiert wurde die Animation: gleiche Animationskanäle werden addiert,
`step`-Keyframes wechseln exakt auf dem Keyframe, und uniforme Größenänderungen
werden wie in der Mod sowohl auf die Modellteilgröße als auch auf den Stretch
angewendet. Eine Regression prüft diese Rechnungen numerisch.

**Grenze:** Es handelt sich weiterhin um einen eigenen WebGL-Renderer und
nicht um die Minecraft-Renderengine. Die tatsächliche iPhone-Darstellung
ist nicht verifiziert. Für Pixelgleichheit fehlen noch direkte
Referenz-Screenshots aus dem Spiel mit identischer Kamera und Animationszeit.

## Beta 0.12 – Renderer-Audit anhand der Original-Mod

- **Cosmetic-Texturen:** Die PNG-Zeilen werden nicht mehr beim Upload nach WebGL gespiegelt. Damit werden die `uv`-Koordinaten der `.cosmetic`-Datei wie in `CosmeticRenderLayer.geometry()` auf die Originalbildzeilen angewendet, einschließlich der 16 Frames der V6-Flügel. Keine Cosmetic-spezifischen Spiegelungsschalter.
- **Spieler-Modell:** Rechts/links waren bei Armen und Beinen vertauscht. Die rechte Seite verwendet nun Minecrafts negative X-Achse, die linke die positive X-Achse. Das betrifft auch den Steve-/Alex-Armmodus.
- **Anker:** Arm-Pivots entsprechen den stehenden `PlayerModel`-Positionen (±5, 2 Modellpixel unter dem Hals); Beine ±1,9 und 12 Pixel unter dem Hals. Kopf und Rumpf bleiben am Hals-Pivot.
- **Transparenz:** Zuerst werden vollständig deckende Cosmetic-Pixel mit Tiefenschreiben gerendert, danach halbtransparente Pixel sortiert ohne Tiefenschreiben. Dadurch verdecken sich Flügellagen und Kopfband nicht mehr willkürlich.
- **Unverändert:** `.cosmetic`-Dateiformat, ZIP-Import, Animation-Keyframes, App-Icon, iOS-Dateiauswahl, vorhandene Beispiele und der GitHub-IPA-Workflow.

Prüfung: JavaScript-Syntax, importierte Beispieldateien, Geometrie-/Animations-/UV-/Skin-Tests. Der Browser in dieser Umgebung blockiert WebGL, daher **keine** visuelle Gleichheitsgarantie mit Minecraft und kein auf iPhone gebautes IPA. Bitte Front-, Rück- und Seitenansicht auf dem Gerät vergleichen.
